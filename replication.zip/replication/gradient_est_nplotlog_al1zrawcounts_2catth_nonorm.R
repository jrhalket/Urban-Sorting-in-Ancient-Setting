

library(readxl)

mino_thick <- read_excel("mino_thick_grad_nonorm_al1z.xlsx")
mino_nonthick <- read_excel("mino_nonthick_grad_nonorm_al1z.xlsx")

hell_thick <- read_excel("hell_local_thick_grad_nonorm_al1z.xlsx")
hell_nonthick <- read_excel("hell_local_nonthick_grad_nonorm_al1z.xlsx")

lrom_thick <- read_excel("lrom_thick_grad_nonorm_al1z.xlsx")
lrom_nonthick <- read_excel("lrom_nonthick_grad_nonorm_al1z.xlsx")



library(gam)


mino_thick_lin <- gam(log1p(mtk_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1mth, family = gaussian, data=mino_thick)
mino_nonthick_lin <- gam(log1p(mntk_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1mth, family = gaussian, data=mino_nonthick)


mino_thick_s <- gam(log1p(mtk_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1mth), family = gaussian, data=mino_thick)
mino_nonthick_s <- gam(log1p(mntk_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1mth), family = gaussian, data=mino_nonthick)



response_mino_thick_lin <- predict(mino_thick_lin, se.fit=T)
response_mino_nonthick_lin <- predict(mino_nonthick_lin, se.fit=T)


response_mino_thick_linf <- response_mino_thick_lin$fit
response_mino_nonthick_linf <- response_mino_nonthick_lin$fit

indf_mino_nonthick<-mino_nonthick$fertcent_dist_gcic_al1mth
indf_mino_thick<-mino_thick$fertcent_dist_gcic_al1mth

response_mino_thick_linf <- response_mino_thick_linf+(1-response_mino_thick_linf[[which.min(indf_mino_thick)]])
response_mino_nonthick_linf <- response_mino_nonthick_linf+(1-response_mino_nonthick_linf[[which.min(indf_mino_nonthick)]])

par(mfcol=c(1,1))

grad_mino_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(0.6,1.2), xlim=c(0,5000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(mino_thick$fertcent_dist_gcic_al1mth , response_mino_thick_linf) , lwd=2 , lty=1, col = "magenta")
lines(smooth.spline(mino_thick$fertcent_dist_gcic_al1mth , response_mino_thick_linf+1.96*response_mino_thick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(mino_thick$fertcent_dist_gcic_al1mth , response_mino_thick_linf-1.96*response_mino_thick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(mino_nonthick$fertcent_dist_gcic_al1mth , response_mino_nonthick_linf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(mino_nonthick$fertcent_dist_gcic_al1mth , response_mino_nonthick_linf+1.96*response_mino_nonthick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(mino_nonthick$fertcent_dist_gcic_al1mth , response_mino_nonthick_linf-1.96*response_mino_nonthick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_al1zrawcounts_mino_linear_nonorm.eps')
dev.off()


response_mino_thick_s <- predict(mino_thick_s, se.fit=T)
response_mino_nonthick_s <- predict(mino_nonthick_s, se.fit=T)


response_mino_thick_sf <- response_mino_thick_s$fit
response_mino_nonthick_sf <- response_mino_nonthick_s$fit


response_mino_thick_sf <- response_mino_thick_sf+(1-response_mino_thick_sf[[which.min(indf_mino_thick)]])
response_mino_nonthick_sf <- response_mino_nonthick_sf+(1-response_mino_nonthick_sf[[which.min(indf_mino_nonthick)]])

par(mfcol=c(1,1))

grad_mino_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(-0.5,1.5), xlim=c(0,5000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(mino_thick$fertcent_dist_gcic_al1mth , response_mino_thick_sf) , lwd=2 , lty=1, col = "magenta")
lines(smooth.spline(mino_thick$fertcent_dist_gcic_al1mth , response_mino_thick_sf+1.96*response_mino_thick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(mino_thick$fertcent_dist_gcic_al1mth , response_mino_thick_sf-1.96*response_mino_thick_s$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(mino_nonthick$fertcent_dist_gcic_al1mth , response_mino_nonthick_sf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(mino_nonthick$fertcent_dist_gcic_al1mth , response_mino_nonthick_sf+1.96*response_mino_nonthick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(mino_nonthick$fertcent_dist_gcic_al1mth , response_mino_nonthick_sf-1.96*response_mino_nonthick_s$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_al1zrawcounts_mino_spline_nonorm.eps')
dev.off()

hell_thick_lin <- gam(log1p(hltk_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hlth, family = gaussian, data=hell_thick)
hell_nonthick_lin <- gam(log1p(hlntk_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hlth, family = gaussian, data=hell_nonthick)


hell_thick_s <- gam(log1p(hltk_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hlth), family = gaussian, data=hell_thick)
hell_nonthick_s <- gam(log1p(hlntk_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hlth), family = gaussian, data=hell_nonthick)


response_hell_thick_lin <- predict(hell_thick_lin, se.fit=T)
response_hell_nonthick_lin <- predict(hell_nonthick_lin, se.fit=T)


response_hell_thick_linf <- response_hell_thick_lin$fit
response_hell_nonthick_linf <- response_hell_nonthick_lin$fit

indf_hell_nonthick<-hell_nonthick$kastro_dist_gcic_al1hlth
indf_hell_thick<-hell_thick$kastro_dist_gcic_al1hlth


response_hell_thick_linf <- response_hell_thick_linf+(1-response_hell_thick_linf[[which.min(indf_hell_thick)]])
response_hell_nonthick_linf <- response_hell_nonthick_linf+(1-response_hell_nonthick_linf[[which.min(indf_hell_nonthick)]])

par(mfcol=c(1,1))

grad_hell_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(0.6,1.2), xlim=c(0,600))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlth , response_hell_thick_linf) , lwd=2 , lty=1, col = "magenta")
lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlth , response_hell_thick_linf+1.96*response_hell_thick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlth , response_hell_thick_linf-1.96*response_hell_thick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlth , response_hell_nonthick_linf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlth , response_hell_nonthick_linf+1.96*response_hell_nonthick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlth , response_hell_nonthick_linf-1.96*response_hell_nonthick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_al1zrawcounts_hell_linear_nonorm.eps')
dev.off()


response_hell_thick_s <- predict(hell_thick_s, se.fit=T)
response_hell_nonthick_s <- predict(hell_nonthick_s, se.fit=T)


response_hell_thick_sf <- response_hell_thick_s$fit
response_hell_nonthick_sf <- response_hell_nonthick_s$fit


response_hell_thick_sf <- response_hell_thick_sf+(1-response_hell_thick_sf[[which.min(indf_hell_thick)]])
response_hell_nonthick_sf <- response_hell_nonthick_sf+(1-response_hell_nonthick_sf[[which.min(indf_hell_nonthick)]])

par(mfcol=c(1,1))

grad_hell_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0.2,1.3), xlim=c(0,600))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlth , response_hell_thick_sf) , lwd=2 , lty=1, col = "magenta")
lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlth , response_hell_thick_sf+1.96*response_hell_thick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlth , response_hell_thick_sf-1.96*response_hell_thick_s$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlth , response_hell_nonthick_sf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlth , response_hell_nonthick_sf+1.96*response_hell_nonthick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlth , response_hell_nonthick_sf-1.96*response_hell_nonthick_s$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_al1zrawcounts_hell_spline_nonorm.eps')
dev.off()

lrom_thick_lin <- gam(log1p(rltk_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rlth, family = gaussian, data=lrom_thick)
lrom_nonthick_lin <- gam(log1p(rlntk_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rlth, family = gaussian, data=lrom_nonthick)


lrom_thick_s <- gam(log1p(rltk_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rlth), family = gaussian, data=lrom_thick)
lrom_nonthick_s <- gam(log1p(rlntk_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rlth), family = gaussian, data=lrom_nonthick)



response_lrom_thick_lin <- predict(lrom_thick_lin, se.fit=T)
response_lrom_nonthick_lin <- predict(lrom_nonthick_lin, se.fit=T)


response_lrom_thick_linf <- response_lrom_thick_lin$fit
response_lrom_nonthick_linf <- response_lrom_nonthick_lin$fit

indf_lrom_nonthick<-lrom_nonthick$potamos_dist_gcic_al1rlth
indf_lrom_thick<-lrom_thick$potamos_dist_gcic_al1rlth


response_lrom_thick_linf <- response_lrom_thick_linf+(1-response_lrom_thick_linf[[which.min(indf_lrom_thick)]])
response_lrom_nonthick_linf <- response_lrom_nonthick_linf+(1-response_lrom_nonthick_linf[[which.min(indf_lrom_nonthick)]])

par(mfcol=c(1,1))

grad_lrom_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(0.6,1.2), xlim=c(0,1500))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(lrom_thick$potamos_dist_gcic_al1rlth , response_lrom_thick_linf) , lwd=2 , lty=1, col = "magenta")
lines(smooth.spline(lrom_thick$potamos_dist_gcic_al1rlth , response_lrom_thick_linf+1.96*response_lrom_thick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_thick$potamos_dist_gcic_al1rlth , response_lrom_thick_linf-1.96*response_lrom_thick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_nonthick$potamos_dist_gcic_al1rlth , response_lrom_nonthick_linf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(lrom_nonthick$potamos_dist_gcic_al1rlth , response_lrom_nonthick_linf+1.96*response_lrom_nonthick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(lrom_nonthick$potamos_dist_gcic_al1rlth , response_lrom_nonthick_linf-1.96*response_lrom_nonthick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_al1zrawcounts_lrompot_linear_nonorm.eps')
dev.off()


response_lrom_thick_s <- predict(lrom_thick_s, se.fit=T)
response_lrom_nonthick_s <- predict(lrom_nonthick_s, se.fit=T)


response_lrom_thick_sf <- response_lrom_thick_s$fit
response_lrom_nonthick_sf <- response_lrom_nonthick_s$fit


response_lrom_thick_sf <- response_lrom_thick_sf+(1-response_lrom_thick_sf[[which.min(indf_lrom_thick)]])
response_lrom_nonthick_sf <- response_lrom_nonthick_sf+(1-response_lrom_nonthick_sf[[which.min(indf_lrom_nonthick)]])

par(mfcol=c(1,1))

grad_lrom_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0.6,1.1), xlim=c(0,1500))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(lrom_thick$potamos_dist_gcic_al1rlth , response_lrom_thick_sf) , lwd=2 , lty=1, col = "magenta")
lines(smooth.spline(lrom_thick$potamos_dist_gcic_al1rlth , response_lrom_thick_sf+1.96*response_lrom_thick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_thick$potamos_dist_gcic_al1rlth , response_lrom_thick_sf-1.96*response_lrom_thick_s$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_nonthick$potamos_dist_gcic_al1rlth , response_lrom_nonthick_sf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(lrom_nonthick$potamos_dist_gcic_al1rlth , response_lrom_nonthick_sf+1.96*response_lrom_nonthick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(lrom_nonthick$potamos_dist_gcic_al1rlth , response_lrom_nonthick_sf-1.96*response_lrom_nonthick_s$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_al1zrawcounts_lrompot_spline_nonorm.eps')
dev.off()

library(readxl)


lromfert_thick <- read_excel("lromfert_thick_grad_nonorm_al1z.xlsx")
lromfert_nonthick <- read_excel("lromfert_nonthick_grad_nonorm_al1z.xlsx")

lromfert_thick_lin <- gam(log1p(rltk_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rlth, family = gaussian, data=lromfert_thick)
lromfert_nonthick_lin <- gam(log1p(rlntk_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rlth, family = gaussian, data=lromfert_nonthick)


lromfert_thick_s <- gam(log1p(rltk_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rlth), family = gaussian, data=lromfert_thick)
lromfert_nonthick_s <- gam(log1p(rlntk_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rlth), family = gaussian, data=lromfert_nonthick)



response_lromfert_thick_lin <- predict(lromfert_thick_lin, se.fit=T)
response_lromfert_nonthick_lin <- predict(lromfert_nonthick_lin, se.fit=T)


response_lromfert_thick_linf <- response_lromfert_thick_lin$fit
response_lromfert_nonthick_linf <- response_lromfert_nonthick_lin$fit

indf_lromfert_nonthick<-lromfert_nonthick$fertcent_dist_gcic_al1rlth
indf_lromfert_thick<-lromfert_thick$fertcent_dist_gcic_al1rlth


response_lromfert_thick_linf <- response_lromfert_thick_linf+(1-response_lromfert_thick_linf[[which.min(indf_lromfert_thick)]])
response_lromfert_nonthick_linf <- response_lromfert_nonthick_linf+(1-response_lromfert_nonthick_linf[[which.min(indf_lromfert_nonthick)]])

par(mfcol=c(1,1))

grad_lromfert_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                          ylab="Log raw counts", lwd=2,ylim=c(0.6,1.2), xlim=c(0,3000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(lromfert_thick$fertcent_dist_gcic_al1rlth , response_lromfert_thick_linf) , lwd=2 , lty=1, col = "magenta")
lines(smooth.spline(lromfert_thick$fertcent_dist_gcic_al1rlth , response_lromfert_thick_linf+1.96*response_lromfert_thick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lromfert_thick$fertcent_dist_gcic_al1rlth , response_lromfert_thick_linf-1.96*response_lromfert_thick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lromfert_nonthick$fertcent_dist_gcic_al1rlth , response_lromfert_nonthick_linf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(lromfert_nonthick$fertcent_dist_gcic_al1rlth , response_lromfert_nonthick_linf+1.96*response_lromfert_nonthick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(lromfert_nonthick$fertcent_dist_gcic_al1rlth , response_lromfert_nonthick_linf-1.96*response_lromfert_nonthick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_al1zrawcounts_lromfert_linear_nonorm.eps')
dev.off()


response_lromfert_thick_s <- predict(lromfert_thick_s, se.fit=T)
response_lromfert_nonthick_s <- predict(lromfert_nonthick_s, se.fit=T)


response_lromfert_thick_sf <- response_lromfert_thick_s$fit
response_lromfert_nonthick_sf <- response_lromfert_nonthick_s$fit


response_lromfert_thick_sf <- response_lromfert_thick_sf+(1-response_lromfert_thick_sf[[which.min(indf_lromfert_thick)]])
response_lromfert_nonthick_sf <- response_lromfert_nonthick_sf+(1-response_lromfert_nonthick_sf[[which.min(indf_lromfert_nonthick)]])

par(mfcol=c(1,1))

grad_lromfert_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                        ylab="Log raw counts", lwd=2,ylim=c(0.85,1.15), xlim=c(0,3000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))

lines(smooth.spline(lromfert_thick$fertcent_dist_gcic_al1rlth , response_lromfert_thick_sf) , lwd=2 , lty=1, col = "magenta")
lines(smooth.spline(lromfert_thick$fertcent_dist_gcic_al1rlth , response_lromfert_thick_sf+1.96*response_lromfert_thick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lromfert_thick$fertcent_dist_gcic_al1rlth , response_lromfert_thick_sf-1.96*response_lromfert_thick_s$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lromfert_nonthick$fertcent_dist_gcic_al1rlth , response_lromfert_nonthick_sf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(lromfert_nonthick$fertcent_dist_gcic_al1rlth , response_lromfert_nonthick_sf+1.96*response_lromfert_nonthick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(lromfert_nonthick$fertcent_dist_gcic_al1rlth , response_lromfert_nonthick_sf-1.96*response_lromfert_nonthick_s$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_al1zrawcounts_lromfert_spline_nonorm.eps')
dev.off()