

library(readxl)

mino_noamph_coarse <- read_excel("mino_noamph_coarse_grad_nonorm_al1z.xlsx")
mino_noamph_medium <- read_excel("mino_noamph_medium_grad_nonorm_al1z.xlsx")
mino_noamph_fine <- read_excel("mino_noamph_fine_grad_nonorm_al1z.xlsx")

hell_coarse <- read_excel("hell_local_noamph_coarse_grad_nonorm_al1z.xlsx")
hell_medium <- read_excel("hell_local_noamph_medium_grad_nonorm_al1z.xlsx")
hell_fine <- read_excel("hell_local_noamph_fine_grad_nonorm_al1z.xlsx")

lrom_noamph_coarse <- read_excel("lrom_noamph_coarse_grad_nonorm_al1z.xlsx")
lrom_noamph_medium <- read_excel("lrom_noamph_medium_grad_nonorm_al1z.xlsx")
lrom_noamph_fine <- read_excel("lrom_noamph_fine_grad_nonorm_al1z.xlsx")



library(gam)


mino_noamph_coarse_lin <- gam(log1p(mnac_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1mna, family = gaussian, data=mino_noamph_coarse)
mino_noamph_medium_lin <- gam(log1p(mnam_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1mna, family = gaussian, data=mino_noamph_medium)
mino_noamph_fine_lin <- gam(log1p(mnaf_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1mna, family = gaussian, data=mino_noamph_fine)


mino_noamph_coarse_s <- gam(log1p(mnac_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1mna), family = gaussian, data=mino_noamph_coarse)
mino_noamph_medium_s <- gam(log1p(mnam_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1mna), family = gaussian, data=mino_noamph_medium)
mino_noamph_fine_s <- gam(log1p(mnaf_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1mna), family = gaussian, data=mino_noamph_fine)


response_mino_noamph_medium_lin <- predict(mino_noamph_medium_lin, se.fit=T)
response_mino_noamph_coarse_lin <- predict(mino_noamph_coarse_lin, se.fit=T)
response_mino_noamph_fine_lin <- predict(mino_noamph_fine_lin, se.fit=T)

response_mino_noamph_medium_linf <- response_mino_noamph_medium_lin$fit
response_mino_noamph_coarse_linf <- response_mino_noamph_coarse_lin$fit
response_mino_noamph_fine_linf <- response_mino_noamph_fine_lin$fit

indf_mino_noamph_fine<-mino_noamph_fine$fertcent_dist_gcic_al1mna
indf_mino_noamph_medium<-mino_noamph_medium$fertcent_dist_gcic_al1mna
indf_mino_noamph_coarse<-mino_noamph_coarse$fertcent_dist_gcic_al1mna

response_mino_noamph_medium_linf <- response_mino_noamph_medium_linf+(1-response_mino_noamph_medium_linf[[which.min(indf_mino_noamph_medium)]])
response_mino_noamph_coarse_linf <- response_mino_noamph_coarse_linf+(1-response_mino_noamph_coarse_linf[[which.min(indf_mino_noamph_coarse)]])
response_mino_noamph_fine_linf <- response_mino_noamph_fine_linf+(1-response_mino_noamph_fine_linf[[which.min(indf_mino_noamph_fine)]])

par(mfcol=c(1,1))

grad_mino_noamphlin <- plot(0, type="n", bty="n",  xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(0.85,1.05), xlim=c(0,5000))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("green","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(mino_noamph_medium$fertcent_dist_gcic_al1mna , response_mino_noamph_medium_linf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mino_noamph_medium$fertcent_dist_gcic_al1mna , response_mino_noamph_medium_linf+1.96*response_mino_noamph_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_noamph_medium$fertcent_dist_gcic_al1mna , response_mino_noamph_medium_linf-1.96*response_mino_noamph_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_noamph_coarse$fertcent_dist_gcic_al1mna , response_mino_noamph_coarse_linf) , lwd=2 , lty=4, col = "green")
lines(smooth.spline(mino_noamph_coarse$fertcent_dist_gcic_al1mna , response_mino_noamph_coarse_linf+1.96*response_mino_noamph_coarse_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_noamph_coarse$fertcent_dist_gcic_al1mna , response_mino_noamph_coarse_linf-1.96*response_mino_noamph_coarse_lin$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_noamph_fine$fertcent_dist_gcic_al1mna , response_mino_noamph_fine_linf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(mino_noamph_fine$fertcent_dist_gcic_al1mna , response_mino_noamph_fine_linf+1.96*response_mino_noamph_fine_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(mino_noamph_fine$fertcent_dist_gcic_al1mna , response_mino_noamph_fine_linf-1.96*response_mino_noamph_fine_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_na_al1zrawcounts_mino_noamphlinear_nonorm.eps')
dev.off()

response_mino_noamph_medium_s <- predict(mino_noamph_medium_s, se.fit=T)
response_mino_noamph_coarse_s <- predict(mino_noamph_coarse_s, se.fit=T)
response_mino_noamph_fine_s <- predict(mino_noamph_fine_s, se.fit=T)

response_mino_noamph_medium_sf <- response_mino_noamph_medium_s$fit
response_mino_noamph_coarse_sf <- response_mino_noamph_coarse_s$fit
response_mino_noamph_fine_sf <- response_mino_noamph_fine_s$fit

response_mino_noamph_medium_sf <- response_mino_noamph_medium_sf+(1-response_mino_noamph_medium_sf[[which.min(indf_mino_noamph_medium)]])
response_mino_noamph_coarse_sf <- response_mino_noamph_coarse_sf+(1-response_mino_noamph_coarse_sf[[which.min(indf_mino_noamph_coarse)]])
response_mino_noamph_fine_sf <- response_mino_noamph_fine_sf+(1-response_mino_noamph_fine_sf[[which.min(indf_mino_noamph_fine)]])

par(mfcol=c(1,1))

grad_mino_noamphs <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0,1.05), xlim=c(0,5000))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("green","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(mino_noamph_medium$fertcent_dist_gcic_al1mna , response_mino_noamph_medium_sf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mino_noamph_medium$fertcent_dist_gcic_al1mna , response_mino_noamph_medium_sf+1.96*response_mino_noamph_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_noamph_medium$fertcent_dist_gcic_al1mna , response_mino_noamph_medium_sf-1.96*response_mino_noamph_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_noamph_coarse$fertcent_dist_gcic_al1mna , response_mino_noamph_coarse_sf) , lwd=2 , lty=4, col = "green")
lines(smooth.spline(mino_noamph_coarse$fertcent_dist_gcic_al1mna , response_mino_noamph_coarse_sf+1.96*response_mino_noamph_coarse_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_noamph_coarse$fertcent_dist_gcic_al1mna , response_mino_noamph_coarse_sf-1.96*response_mino_noamph_coarse_s$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_noamph_fine$fertcent_dist_gcic_al1mna , response_mino_noamph_fine_sf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(mino_noamph_fine$fertcent_dist_gcic_al1mna , response_mino_noamph_fine_sf+1.96*response_mino_noamph_fine_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(mino_noamph_fine$fertcent_dist_gcic_al1mna , response_mino_noamph_fine_sf-1.96*response_mino_noamph_fine_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_na_al1zrawcounts_mino_noamphspline_nonorm.eps')
dev.off()

hell_coarse_lin <- gam(log1p(hlnac_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hlna, family = gaussian, data=hell_coarse)
hell_medium_lin <- gam(log1p(hlnam_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hlna, family = gaussian, data=hell_medium)
hell_fine_lin <- gam(log1p(hlnaf_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hlna, family = gaussian, data=hell_fine)


hell_coarse_s <- gam(log1p(hlnac_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hlna), family = gaussian, data=hell_coarse)
hell_medium_s <- gam(log1p(hlnam_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hlna), family = gaussian, data=hell_medium)
hell_fine_s <- gam(log1p(hlnaf_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hlna), family = gaussian, data=hell_fine)


response_hell_medium_lin <- predict(hell_medium_lin, se.fit=T)
response_hell_coarse_lin <- predict(hell_coarse_lin, se.fit=T)
response_hell_fine_lin <- predict(hell_fine_lin, se.fit=T)

response_hell_medium_linf <- response_hell_medium_lin$fit
response_hell_coarse_linf <- response_hell_coarse_lin$fit
response_hell_fine_linf <- response_hell_fine_lin$fit

indf_hell_fine<-hell_fine$kastro_dist_gcic_al1hlna
indf_hell_medium<-hell_medium$kastro_dist_gcic_al1hlna
indf_hell_coarse<-hell_coarse$kastro_dist_gcic_al1hlna

response_hell_medium_linf <- response_hell_medium_linf+(1-response_hell_medium_linf[[which.min(indf_hell_medium)]])
response_hell_coarse_linf <- response_hell_coarse_linf+(1-response_hell_coarse_linf[[which.min(indf_hell_coarse)]])
response_hell_fine_linf <- response_hell_fine_linf+(1-response_hell_fine_linf[[which.min(indf_hell_fine)]])

par(mfcol=c(1,1))

grad_hell_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(0.85,1.10), xlim=c(0,600))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("green","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hlna , response_hell_medium_linf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hlna , response_hell_medium_linf+1.96*response_hell_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hlna , response_hell_medium_linf-1.96*response_hell_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hlna , response_hell_coarse_linf) , lwd=2 , lty=4, col = "green")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hlna , response_hell_coarse_linf+1.96*response_hell_coarse_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hlna , response_hell_coarse_linf-1.96*response_hell_coarse_lin$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hlna , response_hell_fine_linf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hlna , response_hell_fine_linf+1.96*response_hell_fine_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hlna , response_hell_fine_linf-1.96*response_hell_fine_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_na_al1zrawcounts_hell_linear_nonorm.eps')
dev.off()

response_hell_medium_s <- predict(hell_medium_s, se.fit=T)
response_hell_coarse_s <- predict(hell_coarse_s, se.fit=T)
response_hell_fine_s <- predict(hell_fine_s, se.fit=T)

response_hell_medium_sf <- response_hell_medium_s$fit
response_hell_coarse_sf <- response_hell_coarse_s$fit
response_hell_fine_sf <- response_hell_fine_s$fit

response_hell_medium_sf <- response_hell_medium_sf+(1-response_hell_medium_sf[[which.min(indf_hell_medium)]])
response_hell_coarse_sf <- response_hell_coarse_sf+(1-response_hell_coarse_sf[[which.min(indf_hell_coarse)]])
response_hell_fine_sf <- response_hell_fine_sf+(1-response_hell_fine_sf[[which.min(indf_hell_fine)]])

par(mfcol=c(1,1))

grad_hell_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0.40,1.3), xlim=c(0,600))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("green","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hlna , response_hell_medium_sf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hlna , response_hell_medium_sf+1.96*response_hell_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hlna , response_hell_medium_sf-1.96*response_hell_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hlna , response_hell_coarse_sf) , lwd=2 , lty=4, col = "green")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hlna , response_hell_coarse_sf+1.96*response_hell_coarse_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hlna , response_hell_coarse_sf-1.96*response_hell_coarse_s$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hlna , response_hell_fine_sf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hlna , response_hell_fine_sf+1.96*response_hell_fine_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hlna , response_hell_fine_sf-1.96*response_hell_fine_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_na_al1zrawcounts_hell_spline_nonorm.eps')
dev.off()

lrom_noamph_coarse_lin <- gam(log1p(rlnac_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rlna, family = gaussian, data=lrom_noamph_coarse)
lrom_noamph_medium_lin <- gam(log1p(rlnam_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rlna, family = gaussian, data=lrom_noamph_medium)
lrom_noamph_fine_lin <- gam(log1p(rlnaf_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rlna, family = gaussian, data=lrom_noamph_fine)


lrom_noamph_coarse_s <- gam(log1p(rlnac_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rlna), family = gaussian, data=lrom_noamph_coarse)
lrom_noamph_medium_s <- gam(log1p(rlnam_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rlna), family = gaussian, data=lrom_noamph_medium)
lrom_noamph_fine_s <- gam(log1p(rlnaf_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rlna), family = gaussian, data=lrom_noamph_fine)


response_lrom_noamph_medium_lin <- predict(lrom_noamph_medium_lin, se.fit=T)
response_lrom_noamph_coarse_lin <- predict(lrom_noamph_coarse_lin, se.fit=T)
response_lrom_noamph_fine_lin <- predict(lrom_noamph_fine_lin, se.fit=T)

response_lrom_noamph_medium_linf <- response_lrom_noamph_medium_lin$fit
response_lrom_noamph_coarse_linf <- response_lrom_noamph_coarse_lin$fit
response_lrom_noamph_fine_linf <- response_lrom_noamph_fine_lin$fit

indf_lrom_noamph_fine<-lrom_noamph_fine$potamos_dist_gcic_al1rlna
indf_lrom_noamph_medium<-lrom_noamph_medium$potamos_dist_gcic_al1rlna
indf_lrom_noamph_coarse<-lrom_noamph_coarse$potamos_dist_gcic_al1rlna

response_lrom_noamph_medium_linf <- response_lrom_noamph_medium_linf+(1-response_lrom_noamph_medium_linf[[which.min(indf_lrom_noamph_medium)]])
response_lrom_noamph_coarse_linf <- response_lrom_noamph_coarse_linf+(1-response_lrom_noamph_coarse_linf[[which.min(indf_lrom_noamph_coarse)]])
response_lrom_noamph_fine_linf <- response_lrom_noamph_fine_linf+(1-response_lrom_noamph_fine_linf[[which.min(indf_lrom_noamph_fine)]])

par(mfcol=c(1,1))

grad_lrom_noamphlin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(0.92,1.02), xlim=c(0,1500))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("green","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(lrom_noamph_medium$potamos_dist_gcic_al1rlna , response_lrom_noamph_medium_linf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_noamph_medium$potamos_dist_gcic_al1rlna , response_lrom_noamph_medium_linf+1.96*response_lrom_noamph_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_noamph_medium$potamos_dist_gcic_al1rlna , response_lrom_noamph_medium_linf-1.96*response_lrom_noamph_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_noamph_coarse$potamos_dist_gcic_al1rlna , response_lrom_noamph_coarse_linf) , lwd=2 , lty=4, col = "green")
lines(smooth.spline(lrom_noamph_coarse$potamos_dist_gcic_al1rlna , response_lrom_noamph_coarse_linf+1.96*response_lrom_noamph_coarse_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_noamph_coarse$potamos_dist_gcic_al1rlna , response_lrom_noamph_coarse_linf-1.96*response_lrom_noamph_coarse_lin$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_noamph_fine$potamos_dist_gcic_al1rlna , response_lrom_noamph_fine_linf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(lrom_noamph_fine$potamos_dist_gcic_al1rlna , response_lrom_noamph_fine_linf+1.96*response_lrom_noamph_fine_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lrom_noamph_fine$potamos_dist_gcic_al1rlna , response_lrom_noamph_fine_linf-1.96*response_lrom_noamph_fine_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_na_al1zrawcounts_lrompot_linear_nonorm.eps')
dev.off()

response_lrom_noamph_medium_s <- predict(lrom_noamph_medium_s, se.fit=T)
response_lrom_noamph_coarse_s <- predict(lrom_noamph_coarse_s, se.fit=T)
response_lrom_noamph_fine_s <- predict(lrom_noamph_fine_s, se.fit=T)

response_lrom_noamph_medium_sf <- response_lrom_noamph_medium_s$fit
response_lrom_noamph_coarse_sf <- response_lrom_noamph_coarse_s$fit
response_lrom_noamph_fine_sf <- response_lrom_noamph_fine_s$fit

response_lrom_noamph_medium_sf <- response_lrom_noamph_medium_sf+(1-response_lrom_noamph_medium_sf[[which.min(indf_lrom_noamph_medium)]])
response_lrom_noamph_coarse_sf <- response_lrom_noamph_coarse_sf+(1-response_lrom_noamph_coarse_sf[[which.min(indf_lrom_noamph_coarse)]])
response_lrom_noamph_fine_sf <- response_lrom_noamph_fine_sf+(1-response_lrom_noamph_fine_sf[[which.min(indf_lrom_noamph_fine)]])

par(mfcol=c(1,1))

grad_lrom_noamphs <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0.60,1.1), xlim=c(0,1500))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("green","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(lrom_noamph_medium$potamos_dist_gcic_al1rlna , response_lrom_noamph_medium_sf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_noamph_medium$potamos_dist_gcic_al1rlna , response_lrom_noamph_medium_sf+1.96*response_lrom_noamph_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_noamph_medium$potamos_dist_gcic_al1rlna , response_lrom_noamph_medium_sf-1.96*response_lrom_noamph_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_noamph_coarse$potamos_dist_gcic_al1rlna , response_lrom_noamph_coarse_sf) , lwd=2 , lty=4, col = "green")
lines(smooth.spline(lrom_noamph_coarse$potamos_dist_gcic_al1rlna , response_lrom_noamph_coarse_sf+1.96*response_lrom_noamph_coarse_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_noamph_coarse$potamos_dist_gcic_al1rlna , response_lrom_noamph_coarse_sf-1.96*response_lrom_noamph_coarse_s$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_noamph_fine$potamos_dist_gcic_al1rlna , response_lrom_noamph_fine_sf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(lrom_noamph_fine$potamos_dist_gcic_al1rlna , response_lrom_noamph_fine_sf+1.96*response_lrom_noamph_fine_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lrom_noamph_fine$potamos_dist_gcic_al1rlna , response_lrom_noamph_fine_sf-1.96*response_lrom_noamph_fine_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_na_al1zrawcounts_lrompot_spline_nonorm.eps')
dev.off()

library(readxl)


lrom_noamphfert_coarse <- read_excel("lrom_noamphfert_coarse_grad_nonorm_al1z.xlsx")
lrom_noamphfert_medium <- read_excel("lrom_noamphfert_medium_grad_nonorm_al1z.xlsx")
lrom_noamphfert_fine <- read_excel("lrom_noamphfert_fine_grad_nonorm_al1z.xlsx")

lrom_noamphfert_coarse_lin <- gam(log1p(rlnac_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rlna, family = gaussian, data=lrom_noamphfert_coarse)
lrom_noamphfert_medium_lin <- gam(log1p(rlnam_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rlna, family = gaussian, data=lrom_noamphfert_medium)
lrom_noamphfert_fine_lin <- gam(log1p(rlnaf_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rlna, family = gaussian, data=lrom_noamphfert_fine)


lrom_noamphfert_coarse_s <- gam(log1p(rlnac_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rlna), family = gaussian, data=lrom_noamphfert_coarse)
lrom_noamphfert_medium_s <- gam(log1p(rlnam_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rlna), family = gaussian, data=lrom_noamphfert_medium)
lrom_noamphfert_fine_s <- gam(log1p(rlnaf_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rlna), family = gaussian, data=lrom_noamphfert_fine)


response_lrom_noamphfert_medium_lin <- predict(lrom_noamphfert_medium_lin, se.fit=T)
response_lrom_noamphfert_coarse_lin <- predict(lrom_noamphfert_coarse_lin, se.fit=T)
response_lrom_noamphfert_fine_lin <- predict(lrom_noamphfert_fine_lin, se.fit=T)

response_lrom_noamphfert_medium_linf <- response_lrom_noamphfert_medium_lin$fit
response_lrom_noamphfert_coarse_linf <- response_lrom_noamphfert_coarse_lin$fit
response_lrom_noamphfert_fine_linf <- response_lrom_noamphfert_fine_lin$fit

indf_lrom_noamphfert_fine<-lrom_noamphfert_fine$fertcent_dist_gcic_al1rlna
indf_lrom_noamphfert_medium<-lrom_noamphfert_medium$fertcent_dist_gcic_al1rlna
indf_lrom_noamphfert_coarse<-lrom_noamphfert_coarse$fertcent_dist_gcic_al1rlna

response_lrom_noamphfert_medium_linf <- response_lrom_noamphfert_medium_linf+(1-response_lrom_noamphfert_medium_linf[[which.min(indf_lrom_noamphfert_medium)]])
response_lrom_noamphfert_coarse_linf <- response_lrom_noamphfert_coarse_linf+(1-response_lrom_noamphfert_coarse_linf[[which.min(indf_lrom_noamphfert_coarse)]])
response_lrom_noamphfert_fine_linf <- response_lrom_noamphfert_fine_linf+(1-response_lrom_noamphfert_fine_linf[[which.min(indf_lrom_noamphfert_fine)]])

par(mfcol=c(1,1))

grad_lrom_noamphfert_lin <- plot(0, type="n", bty="n",  xlab="Distance (meters)", 
                          ylab="Log raw counts", lwd=2,ylim=c(0.98,1.04), xlim=c(0,3000))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("green","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(lrom_noamphfert_medium$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_medium_linf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_noamphfert_medium$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_medium_linf+1.96*response_lrom_noamphfert_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_noamphfert_medium$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_medium_linf-1.96*response_lrom_noamphfert_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_noamphfert_coarse$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_coarse_linf) , lwd=2 , lty=4, col = "green")
lines(smooth.spline(lrom_noamphfert_coarse$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_coarse_linf+1.96*response_lrom_noamphfert_coarse_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_noamphfert_coarse$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_coarse_linf-1.96*response_lrom_noamphfert_coarse_lin$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_noamphfert_fine$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_fine_linf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(lrom_noamphfert_fine$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_fine_linf+1.96*response_lrom_noamphfert_fine_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lrom_noamphfert_fine$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_fine_linf-1.96*response_lrom_noamphfert_fine_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_na_al1zrawcounts_lrom_noamphfert_linear_nonorm.eps')
dev.off()

response_lrom_noamphfert_medium_s <- predict(lrom_noamphfert_medium_s, se.fit=T)
response_lrom_noamphfert_coarse_s <- predict(lrom_noamphfert_coarse_s, se.fit=T)
response_lrom_noamphfert_fine_s <- predict(lrom_noamphfert_fine_s, se.fit=T)

response_lrom_noamphfert_medium_sf <- response_lrom_noamphfert_medium_s$fit
response_lrom_noamphfert_coarse_sf <- response_lrom_noamphfert_coarse_s$fit
response_lrom_noamphfert_fine_sf <- response_lrom_noamphfert_fine_s$fit

response_lrom_noamphfert_medium_sf <- response_lrom_noamphfert_medium_sf+(1-response_lrom_noamphfert_medium_sf[[which.min(indf_lrom_noamphfert_medium)]])
response_lrom_noamphfert_coarse_sf <- response_lrom_noamphfert_coarse_sf+(1-response_lrom_noamphfert_coarse_sf[[which.min(indf_lrom_noamphfert_coarse)]])
response_lrom_noamphfert_fine_sf <- response_lrom_noamphfert_fine_sf+(1-response_lrom_noamphfert_fine_sf[[which.min(indf_lrom_noamphfert_fine)]])

par(mfcol=c(1,1))

grad_lrom_noamphfert_s <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                        ylab="Log raw counts", lwd=2,ylim=c(0.8,1.25), xlim=c(0,3000))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("green","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(lrom_noamphfert_medium$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_medium_sf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_noamphfert_medium$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_medium_sf+1.96*response_lrom_noamphfert_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_noamphfert_medium$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_medium_sf-1.96*response_lrom_noamphfert_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_noamphfert_coarse$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_coarse_sf) , lwd=2 , lty=4, col = "green")
lines(smooth.spline(lrom_noamphfert_coarse$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_coarse_sf+1.96*response_lrom_noamphfert_coarse_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_noamphfert_coarse$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_coarse_sf-1.96*response_lrom_noamphfert_coarse_s$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_noamphfert_fine$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_fine_sf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(lrom_noamphfert_fine$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_fine_sf+1.96*response_lrom_noamphfert_fine_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lrom_noamphfert_fine$fertcent_dist_gcic_al1rlna , response_lrom_noamphfert_fine_sf-1.96*response_lrom_noamphfert_fine_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_na_al1zrawcounts_lrom_noamphfert_spline_nonorm.eps')
dev.off()