library(readxl)

mino_fc <- read_excel("mino_fc_grad.xlsx")
mino_fm <- read_excel("mino_fm_grad.xlsx")
mino_mc <- read_excel("mino_mc_grad.xlsx")
mino_pop <- read_excel("mino_pop_grad.xlsx")
hell_fc <- read_excel("hell_fc_grad.xlsx")
hell_fm <- read_excel("hell_fm_grad.xlsx")
hell_mc <- read_excel("hell_mc_grad.xlsx")
hell_pop <- read_excel("hell_pop_grad.xlsx")
erom_fc <- read_excel("erom_fc_grad.xlsx")
erom_fm <- read_excel("erom_fm_grad.xlsx")
erom_mc <- read_excel("erom_mc_grad.xlsx")
erom_pop <- read_excel("erom_pop_grad.xlsx")
mrom_fc <- read_excel("mrom_fc_grad.xlsx")
mrom_fm <- read_excel("mrom_fm_grad.xlsx")
mrom_mc <- read_excel("mrom_mc_grad.xlsx")
mrom_pop <- read_excel("mrom_pop_grad.xlsx")
lrom_fc <- read_excel("lrom_fc_grad.xlsx")
lrom_fm <- read_excel("lrom_fm_grad.xlsx")
lrom_mc <- read_excel("lrom_mc_grad.xlsx")
lrom_pop <- read_excel("lrom_pop_grad.xlsx")


library(gam)

mino_fc_lin <- gam(mino_fc_ratio~fertcent_fc_ratio_mino_dist, family = gaussian, data=mino_fc)
mino_fm_lin <- gam(mino_fm_ratio~fertcent_fm_ratio_mino_dist, family = gaussian, data=mino_fm)
mino_mc_lin <- gam(mino_mc_ratio~fertcent_mc_ratio_mino_dist, family = gaussian, data=mino_mc)
mino_popcounts_lin <- gam(mpopcountsnz~fertcent_mpop_dist, family = gaussian, data=mino_pop)
mino_popwts_lin <- gam(mpopwtsnz~fertcent_mpop_dist, family = gaussian, data=mino_pop)
hell_fc_lin <- gam(hell_fc_ratio~kastro_fc_ratio_hell_dist, family = gaussian, data=hell_fc)
hell_fm_lin <- gam(hell_fm_ratio~kastro_fm_ratio_hell_dist, family = gaussian, data=hell_fm)
hell_mc_lin <- gam(hell_mc_ratio~kastro_mc_ratio_hell_dist, family = gaussian, data=hell_mc)
hell_popcounts_lin <- gam(hpopcountsnz~kastro_hpop_dist, family = gaussian, data=hell_pop)
hell_popwts_lin <- gam(hpopwtsnz~kastro_hpop_dist, family = gaussian, data=hell_pop)
erom_fc_lin <- gam(erom_fc_ratio~kastro_fc_ratio_erom_dist, family = gaussian, data=erom_fc)
erom_fm_lin <- gam(erom_fm_ratio~kastro_fm_ratio_erom_dist, family = gaussian, data=erom_fm)
erom_mc_lin <- gam(erom_mc_ratio~kastro_mc_ratio_erom_dist, family = gaussian, data=erom_mc)
erom_popcounts_lin <- gam(repopcountsnz~kastro_repop_dist, family = gaussian, data=erom_pop)
erom_popwts_lin <- gam(repopwtsnz~kastro_repop_dist, family = gaussian, data=erom_pop)
mrom_fc_lin <- gam(mrom_fc_ratio~potamos_fc_ratio_mrom_dist, family = gaussian, data=mrom_fc)
mrom_fm_lin <- gam(mrom_fm_ratio~potamos_fm_ratio_mrom_dist, family = gaussian, data=mrom_fm)
mrom_mc_lin <- gam(mrom_mc_ratio~potamos_mc_ratio_mrom_dist, family = gaussian, data=mrom_mc)
mrom_popcounts_lin <- gam(rmpopcountsnz~potamos_rmpop_dist, family = gaussian, data=mrom_pop)
mrom_popwts_lin <- gam(rmpopwtsnz~potamos_rmpop_dist, family = gaussian, data=mrom_pop)
lrom_fc_lin <- gam(lrom_fc_ratio~potamos_fc_ratio_lrom_dist, family = gaussian, data=lrom_fc)
lrom_fm_lin <- gam(lrom_fm_ratio~potamos_fm_ratio_lrom_dist, family = gaussian, data=lrom_fm)
lrom_mc_lin <- gam(lrom_mc_ratio~potamos_mc_ratio_lrom_dist, family = gaussian, data=lrom_mc)
lrom_popcounts_lin <- gam(rlpopcountsnz~potamos_rlpop_dist, family = gaussian, data=lrom_pop)
lrom_popwts_lin <- gam(rlpopwtsnz~potamos_rlpop_dist, family = gaussian, data=lrom_pop)

mino_fc_s <- gam(mino_fc_ratio~s(fertcent_fc_ratio_mino_dist), family = gaussian, data=mino_fc)
mino_fm_s <- gam(mino_fm_ratio~s(fertcent_fm_ratio_mino_dist), family = gaussian, data=mino_fm)
mino_mc_s <- gam(mino_mc_ratio~s(fertcent_mc_ratio_mino_dist), family = gaussian, data=mino_mc)
mino_popcounts_s <- gam(mpopcountsnz~s(fertcent_mpop_dist), family = gaussian, data=mino_pop)
mino_popwts_s <- gam(mpopwtsnz~s(fertcent_mpop_dist), family = gaussian, data=mino_pop)
hell_fc_s <- gam(hell_fc_ratio~s(kastro_fc_ratio_hell_dist), family = gaussian, data=hell_fc)
hell_fm_s <- gam(hell_fm_ratio~s(kastro_fm_ratio_hell_dist), family = gaussian, data=hell_fm)
hell_mc_s <- gam(hell_mc_ratio~s(kastro_mc_ratio_hell_dist), family = gaussian, data=hell_mc)
hell_popcounts_s <- gam(hpopcountsnz~s(kastro_hpop_dist), family = gaussian, data=hell_pop)
hell_popwts_s <- gam(hpopwtsnz~s(kastro_hpop_dist), family = gaussian, data=hell_pop)
erom_fc_s <- gam(erom_fc_ratio~s(kastro_fc_ratio_erom_dist), family = gaussian, data=erom_fc)
erom_fm_s <- gam(erom_fm_ratio~s(kastro_fm_ratio_erom_dist), family = gaussian, data=erom_fm)
erom_mc_s <- gam(erom_mc_ratio~s(kastro_mc_ratio_erom_dist), family = gaussian, data=erom_mc)
erom_popcounts_s <- gam(repopcountsnz~s(kastro_repop_dist), family = gaussian, data=erom_pop)
erom_popwts_s <- gam(repopwtsnz~s(kastro_repop_dist), family = gaussian, data=erom_pop)
mrom_fc_s <- gam(mrom_fc_ratio~s(potamos_fc_ratio_mrom_dist), family = gaussian, data=mrom_fc)
mrom_fm_s <- gam(mrom_fm_ratio~s(potamos_fm_ratio_mrom_dist), family = gaussian, data=mrom_fm)
mrom_mc_s <- gam(mrom_mc_ratio~s(potamos_mc_ratio_mrom_dist), family = gaussian, data=mrom_mc)
mrom_popcounts_s <- gam(rmpopcountsnz~s(potamos_rmpop_dist), family = gaussian, data=mrom_pop)
mrom_popwts_s <- gam(rmpopwtsnz~s(potamos_rmpop_dist), family = gaussian, data=mrom_pop)
lrom_fc_s <- gam(lrom_fc_ratio~s(potamos_fc_ratio_lrom_dist), family = gaussian, data=lrom_fc)
lrom_fm_s <- gam(lrom_fm_ratio~s(potamos_fm_ratio_lrom_dist), family = gaussian, data=lrom_fm)
lrom_mc_s <- gam(lrom_mc_ratio~s(potamos_mc_ratio_lrom_dist), family = gaussian, data=lrom_mc)
lrom_popcounts_s <- gam(rlpopcountsnz~s(potamos_rlpop_dist), family = gaussian, data=lrom_pop)
lrom_popwts_s <- gam(rlpopwtsnz~s(potamos_rlpop_dist), family = gaussian, data=lrom_pop)


response_mino_fm_lin <- predict(mino_fm_lin, se.fit=T)
response_mino_fc_lin <- predict(mino_fc_lin, se.fit=T)
response_mino_mc_lin <- predict(mino_mc_lin, se.fit=T)

par(mfcol=c(1,1))

grad_mino_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Wealth ratios", lwd=2,ylim=c(0,3), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(mino_fm$fertcent_fm_ratio_mino_dist , response_mino_fm_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mino_fm$fertcent_fm_ratio_mino_dist , response_mino_fm_lin$fit+1.96*response_mino_fm_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_fm$fertcent_fm_ratio_mino_dist , response_mino_fm_lin$fit-1.96*response_mino_fm_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_fc$fertcent_fc_ratio_mino_dist , response_mino_fc_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(mino_fc$fertcent_fc_ratio_mino_dist , response_mino_fc_lin$fit+1.96*response_mino_fc_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_fc$fertcent_fc_ratio_mino_dist , response_mino_fc_lin$fit-1.96*response_mino_fc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_mc$fertcent_mc_ratio_mino_dist , response_mino_mc_lin$fit) , lwd=2 , col = "blue")
lines(smooth.spline(mino_mc$fertcent_mc_ratio_mino_dist , response_mino_mc_lin$fit+1.96*response_mino_mc_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(mino_mc$fertcent_mc_ratio_mino_dist , response_mino_mc_lin$fit-1.96*response_mino_mc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_mino_linear.eps')
dev.off()


response_popcounts_mino_lin <- predict(mino_popcounts_lin, se.fit=T)
response_popwts_mino_lin <- predict(mino_popwts_lin, se.fit=T)

par(mfcol=c(1,1))

grad_mino_pop_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                          ylab="Absolute consumption", lwd=2,ylim=c(0,30), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popwts_mino_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popwts_mino_lin$fit+1.96*response_popwts_mino_lin$se) 
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popwts_mino_lin$fit-1.96*response_popwts_mino_lin$se) 
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popcounts_mino_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popcounts_mino_lin$fit
                    +1.96*response_popcounts_mino_lin$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popcounts_mino_lin$fit-
                      1.96*response_popcounts_mino_lin$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_mino_linear.eps')
dev.off()


response_mino_fm_s <- predict(mino_fm_s, se.fit=T)
response_mino_fc_s <- predict(mino_fc_s, se.fit=T)
response_mino_mc_s <- predict(mino_mc_s, se.fit=T)

par(mfcol=c(1,1))

grad_mino_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Wealth ratios", lwd=2,ylim=c(0,4), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(mino_fm$fertcent_fm_ratio_mino_dist , response_mino_fm_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mino_fm$fertcent_fm_ratio_mino_dist , response_mino_fm_s$fit+1.96*response_mino_fm_s$se) , lty  
      = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_fm$fertcent_fm_ratio_mino_dist , response_mino_fm_s$fit-1.96*response_mino_fm_s$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_fc$fertcent_fc_ratio_mino_dist , response_mino_fc_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(mino_fc$fertcent_fc_ratio_mino_dist , response_mino_fc_s$fit+1.96*response_mino_fc_s$se) , lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_fc$fertcent_fc_ratio_mino_dist , response_mino_fc_s$fit-1.96*response_mino_fc_s$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_mc$fertcent_mc_ratio_mino_dist , response_mino_mc_s$fit) , lwd=2 , col = "blue")
lines(smooth.spline(mino_mc$fertcent_mc_ratio_mino_dist , response_mino_mc_s$fit+1.96*response_mino_mc_s$se) , lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(mino_mc$fertcent_mc_ratio_mino_dist , response_mino_mc_s$fit-1.96*response_mino_mc_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_mino_spline.eps')
dev.off()

response_popcounts_mino_s <- predict(mino_popcounts_s, se.fit=T)
response_popwts_mino_s <- predict(mino_popwts_s, se.fit=T)

par(mfcol=c(1,1))

grad_mino_pop_s <- plot(0, type="n", bty="n", 
                        xlab="Distance (meters)",  
                        ylab="Absolute consumption", lwd=2,ylim=c(0,30), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popwts_mino_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popwts_mino_s$fit+1.96*response_popwts_mino_s 
                    $se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popwts_mino_s$fit-1.96*response_popwts_mino_s$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popcounts_mino_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popcounts_mino_s$fit 
                    +1.96*response_popcounts_mino_s$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mino_pop$fertcent_mpop_dist , response_popcounts_mino_s$fit- 
                      1.96*response_popcounts_mino_s$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_mino_spline.eps')
dev.off()

response_hell_fm_lin <- predict(hell_fm_lin, se.fit=T)
response_hell_fc_lin <- predict(hell_fc_lin, se.fit=T)
response_hell_mc_lin <- predict(hell_mc_lin, se.fit=T)

par(mfcol=c(1,1))

grad_hell_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                      ylab="Wealth ratios", lwd=2,ylim=c(0,50), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(hell_fm$kastro_fm_ratio_hell_dist , response_hell_fm_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(hell_fm$kastro_fm_ratio_hell_dist , response_hell_fm_lin$fit+1.96*response_hell_fm_lin$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_fm$kastro_fm_ratio_hell_dist , response_hell_fm_lin$fit-1.96*response_hell_fm_lin$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_fc$kastro_fc_ratio_hell_dist , response_hell_fc_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(hell_fc$kastro_fc_ratio_hell_dist , response_hell_fc_lin$fit+1.96*response_hell_fc_lin$se) ,  
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_fc$kastro_fc_ratio_hell_dist , response_hell_fc_lin$fit-1.96*response_hell_fc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_mc$kastro_mc_ratio_hell_dist , response_hell_mc_lin$fit) , lwd=2 , col = "blue")
lines(smooth.spline(hell_mc$kastro_mc_ratio_hell_dist , response_hell_mc_lin$fit+1.96*response_hell_mc_lin$se) ,  
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(hell_mc$kastro_mc_ratio_hell_dist , response_hell_mc_lin$fit-1.96*response_hell_mc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_hell_linear.eps')
dev.off()


response_popcounts_hell_lin <- predict(hell_popcounts_lin, se.fit=T)
response_popwts_hell_lin <- predict(hell_popwts_lin, se.fit=T)

par(mfcol=c(1,1))

grad_hell_pop_lin <- plot(0, type="n", bty="n",  
                          xlab="Distance (meters)",  
                          ylab="Absolute consumption", lwd=2,ylim=c(0,15), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popwts_hell_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popwts_hell_lin$fit+1.96*response_popwts_hell_lin$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popwts_hell_lin$fit-1.96*response_popwts_hell_lin$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popcounts_hell_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popcounts_hell_lin$fit 
                    +1.96*response_popcounts_hell_lin$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popcounts_hell_lin$fit- 
                      1.96*response_popcounts_hell_lin$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_hell_linear.eps')
dev.off()


response_hell_fm_s <- predict(hell_fm_s, se.fit=T)
response_hell_fc_s <- predict(hell_fc_s, se.fit=T)
response_hell_mc_s <- predict(hell_mc_s, se.fit=T)

par(mfcol=c(1,1))

grad_hell_s <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                    ylab="Wealth ratios", lwd=2,ylim=c(0,50), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(hell_fm$kastro_fm_ratio_hell_dist , response_hell_fm_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(hell_fm$kastro_fm_ratio_hell_dist , response_hell_fm_s$fit+1.96*response_hell_fm_s$se) , lty  
      = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_fm$kastro_fm_ratio_hell_dist , response_hell_fm_s$fit-1.96*response_hell_fm_s$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_fc$kastro_fc_ratio_hell_dist , response_hell_fc_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(hell_fc$kastro_fc_ratio_hell_dist , response_hell_fc_s$fit+1.96*response_hell_fc_s$se) , lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_fc$kastro_fc_ratio_hell_dist , response_hell_fc_s$fit-1.96*response_hell_fc_s$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_mc$kastro_mc_ratio_hell_dist , response_hell_mc_s$fit) , lwd=2 , col = "blue")
lines(smooth.spline(hell_mc$kastro_mc_ratio_hell_dist , response_hell_mc_s$fit+1.96*response_hell_mc_s$se) , lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(hell_mc$kastro_mc_ratio_hell_dist , response_hell_mc_s$fit-1.96*response_hell_mc_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_hell_spline.eps')
dev.off()

response_popcounts_hell_s <- predict(hell_popcounts_s, se.fit=T)
response_popwts_hell_s <- predict(hell_popwts_s, se.fit=T)

par(mfcol=c(1,1))

grad_hell_pop_s <- plot(0, type="n", bty="n",  
                        xlab="Distance (meters)",  
                        ylab="Absolute consumption", lwd=2,ylim=c(0,15), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popwts_hell_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popwts_hell_s$fit+1.96*response_popwts_hell_s 
                    $se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popwts_hell_s$fit-1.96*response_popwts_hell_s$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popcounts_hell_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popcounts_hell_s$fit 
                    +1.96*response_popcounts_hell_s$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(hell_pop$kastro_hpop_dist , response_popcounts_hell_s$fit- 
                      1.96*response_popcounts_hell_s$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_hell_spline.eps')
dev.off()

response_erom_fm_lin <- predict(erom_fm_lin, se.fit=T)
response_erom_fc_lin <- predict(erom_fc_lin, se.fit=T)
response_erom_mc_lin <- predict(erom_mc_lin, se.fit=T)

par(mfcol=c(1,1))

grad_erom_lin <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                      ylab="Wealth ratios", lwd=2,ylim=c(0,80), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(erom_fm$kastro_fm_ratio_erom_dist , response_erom_fm_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(erom_fm$kastro_fm_ratio_erom_dist , response_erom_fm_lin$fit+1.96*response_erom_fm_lin$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(erom_fm$kastro_fm_ratio_erom_dist , response_erom_fm_lin$fit-1.96*response_erom_fm_lin$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(erom_fc$kastro_fc_ratio_erom_dist , response_erom_fc_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(erom_fc$kastro_fc_ratio_erom_dist , response_erom_fc_lin$fit+1.96*response_erom_fc_lin$se) ,  
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(erom_fc$kastro_fc_ratio_erom_dist , response_erom_fc_lin$fit-1.96*response_erom_fc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(erom_mc$kastro_mc_ratio_erom_dist , response_erom_mc_lin$fit) , lwd=2 , col = "blue")
lines(smooth.spline(erom_mc$kastro_mc_ratio_erom_dist , response_erom_mc_lin$fit+1.96*response_erom_mc_lin$se) ,  
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(erom_mc$kastro_mc_ratio_erom_dist , response_erom_mc_lin$fit-1.96*response_erom_mc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_erom_linear.eps')
dev.off()


response_popcounts_erom_lin <- predict(erom_popcounts_lin, se.fit=T)
response_popwts_erom_lin <- predict(erom_popwts_lin, se.fit=T)

par(mfcol=c(1,1))

grad_erom_pop_lin <- plot(0, type="n", bty="n", 
                          xlab="Distance (meters)",  
                          ylab="Absolute consumption", lwd=2,ylim=c(0,10), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(erom_pop$kastro_repop_dist , response_popwts_erom_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popwts_erom_lin$fit+1.96*response_popwts_erom_lin$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popwts_erom_lin$fit-1.96*response_popwts_erom_lin$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popcounts_erom_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popcounts_erom_lin$fit 
                    +1.96*response_popcounts_erom_lin$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popcounts_erom_lin$fit- 
                      1.96*response_popcounts_erom_lin$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_erom_linear.eps')
dev.off()


response_erom_fm_s <- predict(erom_fm_s, se.fit=T)
response_erom_fc_s <- predict(erom_fc_s, se.fit=T)
response_erom_mc_s <- predict(erom_mc_s, se.fit=T)

par(mfcol=c(1,1))

grad_erom_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Wealth ratios", lwd=2,ylim=c(0,80), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(erom_fm$kastro_fm_ratio_erom_dist , response_erom_fm_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(erom_fm$kastro_fm_ratio_erom_dist , response_erom_fm_s$fit+1.96*response_erom_fm_s$se) , lty  
      = 3 , lwd = 1 , col = "red")
lines(smooth.spline(erom_fm$kastro_fm_ratio_erom_dist , response_erom_fm_s$fit-1.96*response_erom_fm_s$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(erom_fc$kastro_fc_ratio_erom_dist , response_erom_fc_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(erom_fc$kastro_fc_ratio_erom_dist , response_erom_fc_s$fit+1.96*response_erom_fc_s$se) , lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(erom_fc$kastro_fc_ratio_erom_dist , response_erom_fc_s$fit-1.96*response_erom_fc_s$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(erom_mc$kastro_mc_ratio_erom_dist , response_erom_mc_s$fit) , lwd=2 , col = "blue")
lines(smooth.spline(erom_mc$kastro_mc_ratio_erom_dist , response_erom_mc_s$fit+1.96*response_erom_mc_s$se) , lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(erom_mc$kastro_mc_ratio_erom_dist , response_erom_mc_s$fit-1.96*response_erom_mc_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_erom_spline.eps')
dev.off()

response_popcounts_erom_s <- predict(erom_popcounts_s, se.fit=T)
response_popwts_erom_s <- predict(erom_popwts_s, se.fit=T)

par(mfcol=c(1,1))

grad_erom_pop_s <- plot(0, type="n", bty="n",  
                        xlab="Distance (meters)",  
                        ylab="Absolute consumption", lwd=2,ylim=c(0,10), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(erom_pop$kastro_repop_dist , response_popwts_erom_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popwts_erom_s$fit+1.96*response_popwts_erom_s 
                    $se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popwts_erom_s$fit-1.96*response_popwts_erom_s$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popcounts_erom_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popcounts_erom_s$fit 
                    +1.96*response_popcounts_erom_s$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(erom_pop$kastro_repop_dist , response_popcounts_erom_s$fit- 
                      1.96*response_popcounts_erom_s$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_erom_spline.eps')
dev.off()

response_mrom_fm_lin <- predict(mrom_fm_lin, se.fit=T)
response_mrom_fc_lin <- predict(mrom_fc_lin, se.fit=T)
response_mrom_mc_lin <- predict(mrom_mc_lin, se.fit=T)

par(mfcol=c(1,1))

grad_mrom_lin <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                      ylab="Wealth ratios", lwd=2,ylim=c(0,30), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(mrom_fm$potamos_fm_ratio_mrom_dist , response_mrom_fm_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mrom_fm$potamos_fm_ratio_mrom_dist , response_mrom_fm_lin$fit+1.96*response_mrom_fm_lin$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mrom_fm$potamos_fm_ratio_mrom_dist , response_mrom_fm_lin$fit-1.96*response_mrom_fm_lin$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mrom_fc$potamos_fc_ratio_mrom_dist , response_mrom_fc_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(mrom_fc$potamos_fc_ratio_mrom_dist , response_mrom_fc_lin$fit+1.96*response_mrom_fc_lin$se) ,  
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mrom_fc$potamos_fc_ratio_mrom_dist , response_mrom_fc_lin$fit-1.96*response_mrom_fc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mrom_mc$potamos_mc_ratio_mrom_dist , response_mrom_mc_lin$fit) , lwd=2 , col = "blue")
lines(smooth.spline(mrom_mc$potamos_mc_ratio_mrom_dist , response_mrom_mc_lin$fit+1.96*response_mrom_mc_lin$se) ,  
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(mrom_mc$potamos_mc_ratio_mrom_dist , response_mrom_mc_lin$fit-1.96*response_mrom_mc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_mrom_linear.eps')
dev.off()


response_popcounts_mrom_lin <- predict(mrom_popcounts_lin, se.fit=T)
response_popwts_mrom_lin <- predict(mrom_popwts_lin, se.fit=T)

par(mfcol=c(1,1))

grad_mrom_pop_lin <- plot(0, type="n", bty="n", 
                          xlab="Distance (meters)",  
                          ylab="Absolute consumption", lwd=2,ylim=c(0,30), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popwts_mrom_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popwts_mrom_lin$fit+1.96*response_popwts_mrom_lin$se) 
      
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popwts_mrom_lin$fit-1.96*response_popwts_mrom_lin$se) 
      
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popcounts_mrom_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popcounts_mrom_lin$fit 
                    +1.96*response_popcounts_mrom_lin$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popcounts_mrom_lin$fit- 
                      1.96*response_popcounts_mrom_lin$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_mrom_linear.eps')
dev.off()


response_mrom_fm_s <- predict(mrom_fm_s, se.fit=T)
response_mrom_fc_s <- predict(mrom_fc_s, se.fit=T)
response_mrom_mc_s <- predict(mrom_mc_s, se.fit=T)

par(mfcol=c(1,1))

grad_mrom_s <- plot(0, type="n", bty="n",  xlab="Distance (meters)", 
                    
                    ylab="Wealth ratios", lwd=2,ylim=c(0,30), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(mrom_fm$potamos_fm_ratio_mrom_dist , response_mrom_fm_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mrom_fm$potamos_fm_ratio_mrom_dist , response_mrom_fm_s$fit+1.96*response_mrom_fm_s$se) , lty  
      = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mrom_fm$potamos_fm_ratio_mrom_dist , response_mrom_fm_s$fit-1.96*response_mrom_fm_s$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mrom_fc$potamos_fc_ratio_mrom_dist , response_mrom_fc_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(mrom_fc$potamos_fc_ratio_mrom_dist , response_mrom_fc_s$fit+1.96*response_mrom_fc_s$se) , lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mrom_fc$potamos_fc_ratio_mrom_dist , response_mrom_fc_s$fit-1.96*response_mrom_fc_s$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mrom_mc$potamos_mc_ratio_mrom_dist , response_mrom_mc_s$fit) , lwd=2 , col = "blue")
lines(smooth.spline(mrom_mc$potamos_mc_ratio_mrom_dist , response_mrom_mc_s$fit+1.96*response_mrom_mc_s$se) , lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(mrom_mc$potamos_mc_ratio_mrom_dist , response_mrom_mc_s$fit-1.96*response_mrom_mc_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_mrom_spline.eps')
dev.off()

response_popcounts_mrom_s <- predict(mrom_popcounts_s, se.fit=T)
response_popwts_mrom_s <- predict(mrom_popwts_s, se.fit=T)

par(mfcol=c(1,1))

grad_mrom_pop_s <- plot(0, type="n", bty="n", 
                        xlab="Distance (meters)",  
                        ylab="Absolute consumption", lwd=2,ylim=c(0,30), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popwts_mrom_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popwts_mrom_s$fit+1.96*response_popwts_mrom_s 
                    $se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popwts_mrom_s$fit-1.96*response_popwts_mrom_s$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popcounts_mrom_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popcounts_mrom_s$fit 
                    +1.96*response_popcounts_mrom_s$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(mrom_pop$potamos_rmpop_dist , response_popcounts_mrom_s$fit- 
                      1.96*response_popcounts_mrom_s$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_mrom_spline.eps')
dev.off()

response_lrom_fm_lin <- predict(lrom_fm_lin, se.fit=T)
response_lrom_fc_lin <- predict(lrom_fc_lin, se.fit=T)
response_lrom_mc_lin <- predict(lrom_mc_lin, se.fit=T)

par(mfcol=c(1,1))

grad_lrom_lin <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                      ylab="Wealth ratios", lwd=2,ylim=c(0,40), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(lrom_fm$potamos_fm_ratio_lrom_dist , response_lrom_fm_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_fm$potamos_fm_ratio_lrom_dist , response_lrom_fm_lin$fit+1.96*response_lrom_fm_lin$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_fm$potamos_fm_ratio_lrom_dist , response_lrom_fm_lin$fit-1.96*response_lrom_fm_lin$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_fc$potamos_fc_ratio_lrom_dist , response_lrom_fc_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(lrom_fc$potamos_fc_ratio_lrom_dist , response_lrom_fc_lin$fit+1.96*response_lrom_fc_lin$se) ,  
      lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_fc$potamos_fc_ratio_lrom_dist , response_lrom_fc_lin$fit-1.96*response_lrom_fc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_mc$potamos_mc_ratio_lrom_dist , response_lrom_mc_lin$fit) , lwd=2 , col = "blue")
lines(smooth.spline(lrom_mc$potamos_mc_ratio_lrom_dist , response_lrom_mc_lin$fit+1.96*response_lrom_mc_lin$se) ,  
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lrom_mc$potamos_mc_ratio_lrom_dist , response_lrom_mc_lin$fit-1.96*response_lrom_mc_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_lrom_linear.eps')
dev.off()


response_lrom_fm_s <- predict(lrom_fm_s, se.fit=T)
response_lrom_fc_s <- predict(lrom_fc_s, se.fit=T)
response_lrom_mc_s <- predict(lrom_mc_s, se.fit=T)

par(mfcol=c(1,1))

grad_lrom_s <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                    ylab="Wealth ratios", lwd=2,ylim=c(0,40), xlim=c(0,1500))
legend("topright", bty="n", lwd=2, col=c("green","red","blue"), legend=c("Fine to Coarse", "Fine to Medium","Medium to Coarse"))

lines(smooth.spline(lrom_fm$potamos_fm_ratio_lrom_dist , response_lrom_fm_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_fm$potamos_fm_ratio_lrom_dist , response_lrom_fm_s$fit+1.96*response_lrom_fm_s$se) , lty  
      = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_fm$potamos_fm_ratio_lrom_dist , response_lrom_fm_s$fit-1.96*response_lrom_fm_s$se) ,  
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_fc$potamos_fc_ratio_lrom_dist , response_lrom_fc_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(lrom_fc$potamos_fc_ratio_lrom_dist , response_lrom_fc_s$fit+1.96*response_lrom_fc_s$se) , lty  
      = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_fc$potamos_fc_ratio_lrom_dist , response_lrom_fc_s$fit-1.96*response_lrom_fc_s$se) ,  
      lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_mc$potamos_mc_ratio_lrom_dist , response_lrom_mc_s$fit) , lwd=2 , col = "blue")
lines(smooth.spline(lrom_mc$potamos_mc_ratio_lrom_dist , response_lrom_mc_s$fit+1.96*response_lrom_mc_s$se) , lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lrom_mc$potamos_mc_ratio_lrom_dist , response_lrom_mc_s$fit-1.96*response_lrom_mc_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'grad_lrom_spline.eps')
dev.off()

response_popcounts_lrom_lin <- predict(lrom_popcounts_lin, se.fit=T)
response_popwts_lrom_lin <- predict(lrom_popwts_lin, se.fit=T)

par(mfcol=c(1,1))

grad_lrom_pop_lin <- plot(0, type="n", bty="n",  
                          xlab="Distance (meters)",  
                          ylab="Absolute consumption", lwd=2,ylim=c(0.5,3), xlim=c(0,2000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popwts_lrom_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popwts_lrom_lin$fit+1.96*response_popwts_lrom_lin$se) 
      
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popwts_lrom_lin$fit-1.96*response_popwts_lrom_lin$se) 
      
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popcounts_lrom_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popcounts_lrom_lin$fit 
                    +1.96*response_popcounts_lrom_lin$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popcounts_lrom_lin$fit- 
                      1.96*response_popcounts_lrom_lin$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_lrompot_linear.eps')
dev.off()


response_popcounts_lrom_s <- predict(lrom_popcounts_s, se.fit=T)
response_popwts_lrom_s <- predict(lrom_popwts_s, se.fit=T)

par(mfcol=c(1,1))

grad_lrom_pop_s <- plot(0, type="n", bty="n", 
                        xlab="Distance (meters)",  
                        ylab="Absolute consumption", lwd=2,ylim=c(0.5,3), xlim=c(0,2000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popwts_lrom_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popwts_lrom_s$fit+1.96*response_popwts_lrom_s 
                    $se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popwts_lrom_s$fit-1.96*response_popwts_lrom_s$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popcounts_lrom_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popcounts_lrom_s$fit 
                    +1.96*response_popcounts_lrom_s$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lrom_pop$potamos_rlpop_dist , response_popcounts_lrom_s$fit- 
                      1.96*response_popcounts_lrom_s$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_lrompot_spline.eps')
dev.off()


library(readxl)

lromfert_pop <- read_excel("lromfert_pop_grad.xlsx")

lrom_popcounts_lin <- gam(rlpopcountsnz~fertcent_rlpop_dist, family = gaussian, data=lromfert_pop)
lrom_popwts_lin <- gam(rlpopwtsnz~fertcent_rlpop_dist, family = gaussian, data=lromfert_pop)

response_popcounts_lrom_s <- predict(lrom_popcounts_s, se.fit=T)
response_popwts_lrom_s <- predict(lrom_popwts_s, se.fit=T)

par(mfcol=c(1,1))

grad_lrom_pop_lin <- plot(0, type="n", bty="n", 
                          xlab="Distance (meters)",  
                          ylab="Absolute consumption", lwd=2,ylim=c(0.5,3), xlim=c(0,2500))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popwts_lrom_lin$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popwts_lrom_lin$fit+1.96*response_popwts_lrom_lin 
                    $se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popwts_lrom_lin$fit-1.96*response_popwts_lrom_lin$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popcounts_lrom_lin$fit) , lwd=2 , col = "green")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popcounts_lrom_lin$fit 
                    +1.96*response_popcounts_lrom_lin$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popcounts_lrom_lin$fit- 
                      1.96*response_popcounts_lrom_lin$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_lromfert_lin.eps')
dev.off()

grad_lrom_pop_s <- plot(0, type="n", bty="n",   
                        xlab="Distance (meters)",  
                        ylab="Absolute consumption", lwd=2,ylim=c(0.5,2.5), xlim=c(0,8000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("green","red"), legend=c("Raw counts", "Probability weighted counts"))

lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popwts_lrom_s$fit) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popwts_lrom_s$fit+1.96*response_popwts_lrom_s 
                    $se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popwts_lrom_s$fit-1.96*response_popwts_lrom_s$se)  
      , lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popcounts_lrom_s$fit) , lwd=2 , col = "green")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popcounts_lrom_s$fit 
                    +1.96*response_popcounts_lrom_s$se) , lty = 3 , lwd = 1 , col = "green")
lines(smooth.spline(lromfert_pop$fertcent_rlpop_dist , response_popcounts_lrom_s$fit- 
                      1.96*response_popcounts_lrom_s$se) , lty = 3 , lwd = 1 , col = "green")

dev.copy(postscript,'grad_pop_lromfert_spline.eps')
dev.off()