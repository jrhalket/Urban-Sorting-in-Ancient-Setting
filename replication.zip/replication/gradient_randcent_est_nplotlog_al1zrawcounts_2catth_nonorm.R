

library(readxl)



hell_thick <- read_excel("hell_randomcent_local_thick_grad_nonorm_al1z.xlsx")
hell_nonthick <- read_excel("hell_randomcent_local_nonthick_grad_nonorm_al1z.xlsx")


library(gam)
hell_thick_s <- gam(log1p(hltk_gcic_al1_nonorm_1)~s(randomcent_dist_gcic_al1hlth), family = gaussian, data=hell_thick)
hell_nonthick_s <- gam(log1p(hlntk_gcic_al1_nonorm_1)~s(randomcent_dist_gcic_al1hlth), family = gaussian, data=hell_nonthick)


response_hell_thick_s <- predict(hell_thick_s, se.fit=T)
response_hell_nonthick_s <- predict(hell_nonthick_s, se.fit=T)


response_hell_thick_sf <- response_hell_thick_s$fit
response_hell_nonthick_sf <- response_hell_nonthick_s$fit

indf_hell_nonthick<-hell_nonthick$randomcent_dist_gcic_al1hlth
indf_hell_thick<-hell_thick$randomcent_dist_gcic_al1hlth

response_hell_thick_sf <- response_hell_thick_sf+(1-response_hell_thick_sf[[which.min(indf_hell_thick)]])
response_hell_nonthick_sf <- response_hell_nonthick_sf+(1-response_hell_nonthick_sf[[which.min(indf_hell_nonthick)]])

par(mfcol=c(1,1))

grad_hell_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0.7,1.7), xlim=c(2000,4000))

legend("topright", bty="n", lwd=2, lty=c(1,5),col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(hell_thick$randomcent_dist_gcic_al1hlth , response_hell_thick_sf) , lty=1, lwd=2 , col = "magenta")
lines(smooth.spline(hell_thick$randomcent_dist_gcic_al1hlth , response_hell_thick_sf+1.96*response_hell_thick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_thick$randomcent_dist_gcic_al1hlth , response_hell_thick_sf-1.96*response_hell_thick_s$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_nonthick$randomcent_dist_gcic_al1hlth , response_hell_nonthick_sf) ,lty=5, lwd=2 , col = "orange")
lines(smooth.spline(hell_nonthick$randomcent_dist_gcic_al1hlth , response_hell_nonthick_sf+1.96*response_hell_nonthick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(hell_nonthick$randomcent_dist_gcic_al1hlth , response_hell_nonthick_sf-1.96*response_hell_nonthick_s$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_randcent_al1zrawcounts_hell_spline_nonorm.eps')
