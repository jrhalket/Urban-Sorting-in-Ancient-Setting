

library(readxl)

mino_coarse <- read_excel("mino_coarse_grad_nonorm_al1z.xlsx")
mino_medium <- read_excel("mino_medium_grad_nonorm_al1z.xlsx")
mino_fine <- read_excel("mino_fine_grad_nonorm_al1z.xlsx")

hell_coarse <- read_excel("hell_local_coarse_grad_nonorm_al1z.xlsx")
hell_medium <- read_excel("hell_local_medium_grad_nonorm_al1z.xlsx")
hell_fine <- read_excel("hell_local_fine_grad_nonorm_al1z.xlsx")

lrom_coarse <- read_excel("lrom_coarse_grad_nonorm_al1z.xlsx")
lrom_medium <- read_excel("lrom_medium_grad_nonorm_al1z.xlsx")
lrom_fine <- read_excel("lrom_fine_grad_nonorm_al1z.xlsx")



library(gam)


mino_coarse_lin <- gam(log1p(mc_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1m, family = gaussian, data=mino_coarse)
mino_medium_lin <- gam(log1p(mm_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1m, family = gaussian, data=mino_medium)
mino_fine_lin <- gam(log1p(mf_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1m, family = gaussian, data=mino_fine)


mino_coarse_s <- gam(log1p(mc_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1m), family = gaussian, data=mino_coarse)
mino_medium_s <- gam(log1p(mm_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1m), family = gaussian, data=mino_medium)
mino_fine_s <- gam(log1p(mf_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1m), family = gaussian, data=mino_fine)


response_mino_medium_lin <- predict(mino_medium_lin,se.fit=T)
response_mino_coarse_lin <- predict(mino_coarse_lin,se.fit=T)
response_mino_fine_lin <- predict(mino_fine_lin,se.fit=T)

response_mino_medium_linf <- response_mino_medium_lin$fit
response_mino_coarse_linf <- response_mino_coarse_lin$fit
response_mino_fine_linf <- response_mino_fine_lin$fit

indf_mino_fine<-mino_fine$fertcent_dist_gcic_al1m
indf_mino_medium<-mino_medium$fertcent_dist_gcic_al1m
indf_mino_coarse<-mino_coarse$fertcent_dist_gcic_al1m

response_mino_medium_linf <- response_mino_medium_linf+(1-response_mino_medium_linf[[which.min(indf_mino_medium)]])
response_mino_coarse_linf <- response_mino_coarse_linf+(1-response_mino_coarse_linf[[which.min(indf_mino_coarse)]])
response_mino_fine_linf <- response_mino_fine_linf+(1-response_mino_fine_linf[[which.min(indf_mino_fine)]])

par(mfcol=c(1,1))

grad_mino_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(-0.2,1.8), xlim=c(0,5000))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("black","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(mino_medium$fertcent_dist_gcic_al1m , response_mino_medium_linf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mino_medium$fertcent_dist_gcic_al1m , response_mino_medium_linf+1.96*response_mino_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_medium$fertcent_dist_gcic_al1m , response_mino_medium_linf-1.96*response_mino_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_coarse$fertcent_dist_gcic_al1m , response_mino_coarse_linf) , lwd=2 , lty=4, col = "black")
lines(smooth.spline(mino_coarse$fertcent_dist_gcic_al1m , response_mino_coarse_linf+1.96*response_mino_coarse_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "black")
lines(smooth.spline(mino_coarse$fertcent_dist_gcic_al1m , response_mino_coarse_linf-1.96*response_mino_coarse_lin$se) ,  
      lty = 3 , lwd = 1 , col = "black")
lines(smooth.spline(mino_fine$fertcent_dist_gcic_al1m , response_mino_fine_linf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(mino_fine$fertcent_dist_gcic_al1m , response_mino_fine_linf+1.96*response_mino_fine_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(mino_fine$fertcent_dist_gcic_al1m , response_mino_fine_linf-1.96*response_mino_fine_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_al1zrawcounts_mino_linear_nonorm.eps')
dev.off()

response_mino_medium_s <- predict(mino_medium_s,se.fit=T)
response_mino_coarse_s <- predict(mino_coarse_s,se.fit=T)
response_mino_fine_s <- predict(mino_fine_s,se.fit=T)

response_mino_medium_sf <- response_mino_medium_s$fit
response_mino_coarse_sf <- response_mino_coarse_s$fit
response_mino_fine_sf <- response_mino_fine_s$fit

response_mino_medium_sf <- response_mino_medium_sf+(1-response_mino_medium_sf[[which.min(indf_mino_medium)]])
response_mino_coarse_sf <- response_mino_coarse_sf+(1-response_mino_coarse_sf[[which.min(indf_mino_coarse)]])
response_mino_fine_sf <- response_mino_fine_sf+(1-response_mino_fine_sf[[which.min(indf_mino_fine)]])

par(mfcol=c(1,1))

grad_mino_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(-0.2,1.2), xlim=c(0,5000))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("black","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(mino_medium$fertcent_dist_gcic_al1m , response_mino_medium_sf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(mino_medium$fertcent_dist_gcic_al1m , response_mino_medium_sf+1.96*response_mino_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_medium$fertcent_dist_gcic_al1m , response_mino_medium_sf-1.96*response_mino_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(mino_coarse$fertcent_dist_gcic_al1m , response_mino_coarse_sf) , lwd=2 , lty=4, col = "black")
lines(smooth.spline(mino_coarse$fertcent_dist_gcic_al1m , response_mino_coarse_sf+1.96*response_mino_coarse_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "black")
lines(smooth.spline(mino_coarse$fertcent_dist_gcic_al1m , response_mino_coarse_sf-1.96*response_mino_coarse_s$se) ,  
      lty = 3 , lwd = 1 , col = "black")
lines(smooth.spline(mino_fine$fertcent_dist_gcic_al1m , response_mino_fine_sf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(mino_fine$fertcent_dist_gcic_al1m , response_mino_fine_sf+1.96*response_mino_fine_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(mino_fine$fertcent_dist_gcic_al1m , response_mino_fine_sf-1.96*response_mino_fine_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_al1zrawcounts_mino_spline_nonorm.eps')
dev.off()

hell_coarse_lin <- gam(log1p(hlc_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hl, family = gaussian, data=hell_coarse)
hell_medium_lin <- gam(log1p(hlm_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hl, family = gaussian, data=hell_medium)
hell_fine_lin <- gam(log1p(hlf_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hl, family = gaussian, data=hell_fine)


hell_coarse_s <- gam(log1p(hlc_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hl), family = gaussian, data=hell_coarse)
hell_medium_s <- gam(log1p(hlm_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hl), family = gaussian, data=hell_medium)
hell_fine_s <- gam(log1p(hlf_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hl), family = gaussian, data=hell_fine)


response_hell_medium_lin <- predict(hell_medium_lin,se.fit=T)
response_hell_coarse_lin <- predict(hell_coarse_lin,se.fit=T)
response_hell_fine_lin <- predict(hell_fine_lin,se.fit=T)

response_hell_medium_linf <- response_hell_medium_lin$fit
response_hell_coarse_linf <- response_hell_coarse_lin$fit
response_hell_fine_linf <- response_hell_fine_lin$fit

indf_hell_fine<-hell_fine$kastro_dist_gcic_al1hl
indf_hell_medium<-hell_medium$kastro_dist_gcic_al1hl
indf_hell_coarse<-hell_coarse$kastro_dist_gcic_al1hl

response_hell_medium_linf <- response_hell_medium_linf+(1-response_hell_medium_linf[[which.min(indf_hell_medium)]])
response_hell_coarse_linf <- response_hell_coarse_linf+(1-response_hell_coarse_linf[[which.min(indf_hell_coarse)]])
response_hell_fine_linf <- response_hell_fine_linf+(1-response_hell_fine_linf[[which.min(indf_hell_fine)]])

par(mfcol=c(1,1))

grad_hell_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(-0.1,1.7), xlim=c(0,600))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("black","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hl , response_hell_medium_linf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hl , response_hell_medium_linf+1.96*response_hell_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hl , response_hell_medium_linf-1.96*response_hell_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hl , response_hell_coarse_linf) , lwd=2 , lty=4, col = "black")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hl , response_hell_coarse_linf+1.96*response_hell_coarse_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "black")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hl , response_hell_coarse_linf-1.96*response_hell_coarse_lin$se) ,  
      lty = 3 , lwd = 1 , col = "black")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hl , response_hell_fine_linf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hl , response_hell_fine_linf+1.96*response_hell_fine_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hl , response_hell_fine_linf-1.96*response_hell_fine_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_al1zrawcounts_hell_linear_nonorm.eps')
dev.off()

response_hell_medium_s <- predict(hell_medium_s,se.fit=T)
response_hell_coarse_s <- predict(hell_coarse_s,se.fit=T)
response_hell_fine_s <- predict(hell_fine_s,se.fit=T)

response_hell_medium_sf <- response_hell_medium_s$fit
response_hell_coarse_sf <- response_hell_coarse_s$fit
response_hell_fine_sf <- response_hell_fine_s$fit

response_hell_medium_sf <- response_hell_medium_sf+(1-response_hell_medium_sf[[which.min(indf_hell_medium)]])
response_hell_coarse_sf <- response_hell_coarse_sf+(1-response_hell_coarse_sf[[which.min(indf_hell_coarse)]])
response_hell_fine_sf <- response_hell_fine_sf+(1-response_hell_fine_sf[[which.min(indf_hell_fine)]])

par(mfcol=c(1,1))

grad_hell_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0.1,1.2), xlim=c(0,600))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("black","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hl , response_hell_medium_sf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hl , response_hell_medium_sf+1.96*response_hell_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_medium$kastro_dist_gcic_al1hl , response_hell_medium_sf-1.96*response_hell_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hl , response_hell_coarse_sf) , lwd=2 , lty=4, col = "black")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hl , response_hell_coarse_sf+1.96*response_hell_coarse_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "black")
lines(smooth.spline(hell_coarse$kastro_dist_gcic_al1hl , response_hell_coarse_sf-1.96*response_hell_coarse_s$se) ,  
      lty = 3 , lwd = 1 , col = "black")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hl , response_hell_fine_sf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hl , response_hell_fine_sf+1.96*response_hell_fine_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(hell_fine$kastro_dist_gcic_al1hl , response_hell_fine_sf-1.96*response_hell_fine_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_al1zrawcounts_hell_spline_nonorm.eps')
dev.off()

lrom_coarse_lin <- gam(log1p(rlc_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rl, family = gaussian, data=lrom_coarse)
lrom_medium_lin <- gam(log1p(rlm_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rl, family = gaussian, data=lrom_medium)
lrom_fine_lin <- gam(log1p(rlf_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rl, family = gaussian, data=lrom_fine)


lrom_coarse_s <- gam(log1p(rlc_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rl), family = gaussian, data=lrom_coarse)
lrom_medium_s <- gam(log1p(rlm_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rl), family = gaussian, data=lrom_medium)
lrom_fine_s <- gam(log1p(rlf_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rl), family = gaussian, data=lrom_fine)


response_lrom_medium_lin <- predict(lrom_medium_lin,se.fit=T)
response_lrom_coarse_lin <- predict(lrom_coarse_lin,se.fit=T)
response_lrom_fine_lin <- predict(lrom_fine_lin,se.fit=T)

response_lrom_medium_linf <- response_lrom_medium_lin$fit
response_lrom_coarse_linf <- response_lrom_coarse_lin$fit
response_lrom_fine_linf <- response_lrom_fine_lin$fit

indf_lrom_fine<-lrom_fine$potamos_dist_gcic_al1rl
indf_lrom_medium<-lrom_medium$potamos_dist_gcic_al1rl
indf_lrom_coarse<-lrom_coarse$potamos_dist_gcic_al1rl

response_lrom_medium_linf <- response_lrom_medium_linf+(1-response_lrom_medium_linf[[which.min(indf_lrom_medium)]])
response_lrom_coarse_linf <- response_lrom_coarse_linf+(1-response_lrom_coarse_linf[[which.min(indf_lrom_coarse)]])
response_lrom_fine_linf <- response_lrom_fine_linf+(1-response_lrom_fine_linf[[which.min(indf_lrom_fine)]])

par(mfcol=c(1,1))

grad_lrom_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(-0.1,1.7), xlim=c(0,1500))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("black","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(lrom_medium$potamos_dist_gcic_al1rl , response_lrom_medium_linf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_medium$potamos_dist_gcic_al1rl , response_lrom_medium_linf+1.96*response_lrom_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_medium$potamos_dist_gcic_al1rl , response_lrom_medium_linf-1.96*response_lrom_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_coarse$potamos_dist_gcic_al1rl , response_lrom_coarse_linf) , lwd=2 , lty=4, col = "black")
lines(smooth.spline(lrom_coarse$potamos_dist_gcic_al1rl , response_lrom_coarse_linf+1.96*response_lrom_coarse_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "black")
lines(smooth.spline(lrom_coarse$potamos_dist_gcic_al1rl , response_lrom_coarse_linf-1.96*response_lrom_coarse_lin$se) ,  
      lty = 3 , lwd = 1 , col = "black")
lines(smooth.spline(lrom_fine$potamos_dist_gcic_al1rl , response_lrom_fine_linf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(lrom_fine$potamos_dist_gcic_al1rl , response_lrom_fine_linf+1.96*response_lrom_fine_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lrom_fine$potamos_dist_gcic_al1rl , response_lrom_fine_linf-1.96*response_lrom_fine_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_al1zrawcounts_lrompot_linear_nonorm.eps')
dev.off()

response_lrom_medium_s <- predict(lrom_medium_s,se.fit=T)
response_lrom_coarse_s <- predict(lrom_coarse_s,se.fit=T)
response_lrom_fine_s <- predict(lrom_fine_s,se.fit=T)

response_lrom_medium_sf <- response_lrom_medium_s$fit
response_lrom_coarse_sf <- response_lrom_coarse_s$fit
response_lrom_fine_sf <- response_lrom_fine_s$fit

response_lrom_medium_sf <- response_lrom_medium_sf+(1-response_lrom_medium_sf[[which.min(indf_lrom_medium)]])
response_lrom_coarse_sf <- response_lrom_coarse_sf+(1-response_lrom_coarse_sf[[which.min(indf_lrom_coarse)]])
response_lrom_fine_sf <- response_lrom_fine_sf+(1-response_lrom_fine_sf[[which.min(indf_lrom_fine)]])

par(mfcol=c(1,1))

grad_lrom_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0.6,1.1), xlim=c(0,1500))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("black","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(lrom_medium$potamos_dist_gcic_al1rl , response_lrom_medium_sf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lrom_medium$potamos_dist_gcic_al1rl , response_lrom_medium_sf+1.96*response_lrom_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_medium$potamos_dist_gcic_al1rl , response_lrom_medium_sf-1.96*response_lrom_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lrom_coarse$potamos_dist_gcic_al1rl , response_lrom_coarse_sf) , lwd=2 , lty=4, col = "black")
lines(smooth.spline(lrom_coarse$potamos_dist_gcic_al1rl , response_lrom_coarse_sf+1.96*response_lrom_coarse_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "black")
lines(smooth.spline(lrom_coarse$potamos_dist_gcic_al1rl , response_lrom_coarse_sf-1.96*response_lrom_coarse_s$se) ,  
      lty = 3 , lwd = 1 , col = "black")
lines(smooth.spline(lrom_fine$potamos_dist_gcic_al1rl , response_lrom_fine_sf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(lrom_fine$potamos_dist_gcic_al1rl , response_lrom_fine_sf+1.96*response_lrom_fine_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lrom_fine$potamos_dist_gcic_al1rl , response_lrom_fine_sf-1.96*response_lrom_fine_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_al1zrawcounts_lrompot_spline_nonorm.eps')
dev.off()

library(readxl)


lromfert_coarse <- read_excel("lromfert_coarse_grad_nonorm_al1z.xlsx")
lromfert_medium <- read_excel("lromfert_medium_grad_nonorm_al1z.xlsx")
lromfert_fine <- read_excel("lromfert_fine_grad_nonorm_al1z.xlsx")

lromfert_coarse_lin <- gam(log1p(rlc_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rl, family = gaussian, data=lromfert_coarse)
lromfert_medium_lin <- gam(log1p(rlm_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rl, family = gaussian, data=lromfert_medium)
lromfert_fine_lin <- gam(log1p(rlf_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rl, family = gaussian, data=lromfert_fine)


lromfert_coarse_s <- gam(log1p(rlc_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rl), family = gaussian, data=lromfert_coarse)
lromfert_medium_s <- gam(log1p(rlm_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rl), family = gaussian, data=lromfert_medium)
lromfert_fine_s <- gam(log1p(rlf_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rl), family = gaussian, data=lromfert_fine)


response_lromfert_medium_lin <- predict(lromfert_medium_lin,se.fit=T)
response_lromfert_coarse_lin <- predict(lromfert_coarse_lin,se.fit=T)
response_lromfert_fine_lin <- predict(lromfert_fine_lin,se.fit=T)

response_lromfert_medium_linf <- response_lromfert_medium_lin$fit
response_lromfert_coarse_linf <- response_lromfert_coarse_lin$fit
response_lromfert_fine_linf <- response_lromfert_fine_lin$fit

indf_lromfert_fine<-lromfert_fine$fertcent_dist_gcic_al1rl
indf_lromfert_medium<-lromfert_medium$fertcent_dist_gcic_al1rl
indf_lromfert_coarse<-lromfert_coarse$fertcent_dist_gcic_al1rl

response_lromfert_medium_linf <- response_lromfert_medium_linf+(1-response_lromfert_medium_linf[[which.min(indf_lromfert_medium)]])
response_lromfert_coarse_linf <- response_lromfert_coarse_linf+(1-response_lromfert_coarse_linf[[which.min(indf_lromfert_coarse)]])
response_lromfert_fine_linf <- response_lromfert_fine_linf+(1-response_lromfert_fine_linf[[which.min(indf_lromfert_fine)]])

par(mfcol=c(1,1))

grad_lromfert_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                          ylab="Log raw counts", lwd=2,ylim=c(-0.1,1.2), xlim=c(0,3000))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("black","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(lromfert_medium$fertcent_dist_gcic_al1rl , response_lromfert_medium_linf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lromfert_medium$fertcent_dist_gcic_al1rl , response_lromfert_medium_linf+1.96*response_lromfert_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lromfert_medium$fertcent_dist_gcic_al1rl , response_lromfert_medium_linf-1.96*response_lromfert_medium_lin$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lromfert_coarse$fertcent_dist_gcic_al1rl , response_lromfert_coarse_linf) , lwd=2 , lty=4, col = "black")
lines(smooth.spline(lromfert_coarse$fertcent_dist_gcic_al1rl , response_lromfert_coarse_linf+1.96*response_lromfert_coarse_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "black")
lines(smooth.spline(lromfert_coarse$fertcent_dist_gcic_al1rl , response_lromfert_coarse_linf-1.96*response_lromfert_coarse_lin$se) ,  
      lty = 3 , lwd = 1 , col = "black")
lines(smooth.spline(lromfert_fine$fertcent_dist_gcic_al1rl , response_lromfert_fine_linf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(lromfert_fine$fertcent_dist_gcic_al1rl , response_lromfert_fine_linf+1.96*response_lromfert_fine_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lromfert_fine$fertcent_dist_gcic_al1rl , response_lromfert_fine_linf-1.96*response_lromfert_fine_lin$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_al1zrawcounts_lromfert_linear_nonorm.eps')
dev.off()

response_lromfert_medium_s <- predict(lromfert_medium_s,se.fit=T)
response_lromfert_coarse_s <- predict(lromfert_coarse_s,se.fit=T)
response_lromfert_fine_s <- predict(lromfert_fine_s,se.fit=T)

response_lromfert_medium_sf <- response_lromfert_medium_s$fit
response_lromfert_coarse_sf <- response_lromfert_coarse_s$fit
response_lromfert_fine_sf <- response_lromfert_fine_s$fit

response_lromfert_medium_sf <- response_lromfert_medium_sf+(1-response_lromfert_medium_sf[[which.min(indf_lromfert_medium)]])
response_lromfert_coarse_sf <- response_lromfert_coarse_sf+(1-response_lromfert_coarse_sf[[which.min(indf_lromfert_coarse)]])
response_lromfert_fine_sf <- response_lromfert_fine_sf+(1-response_lromfert_fine_sf[[which.min(indf_lromfert_fine)]])

par(mfcol=c(1,1))

grad_lromfert_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                        ylab="Log raw counts", lwd=2,ylim=c(0.8,1.2), xlim=c(0,3000))
legend("topright", bty="n", lwd=2, lty=c(4, 5, 1), col=c("black","red","blue"), legend=c("Coarse", "Medium","Fine"))

lines(smooth.spline(lromfert_medium$fertcent_dist_gcic_al1rl , response_lromfert_medium_sf) , lwd=2 , lty=5, col = "red")
lines(smooth.spline(lromfert_medium$fertcent_dist_gcic_al1rl , response_lromfert_medium_sf+1.96*response_lromfert_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lromfert_medium$fertcent_dist_gcic_al1rl , response_lromfert_medium_sf-1.96*response_lromfert_medium_s$se) , 
      lty = 3 , lwd = 1 , col = "red")
lines(smooth.spline(lromfert_coarse$fertcent_dist_gcic_al1rl , response_lromfert_coarse_sf) , lwd=2 , lty=4, col = "black")
lines(smooth.spline(lromfert_coarse$fertcent_dist_gcic_al1rl , response_lromfert_coarse_sf+1.96*response_lromfert_coarse_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "black")
lines(smooth.spline(lromfert_coarse$fertcent_dist_gcic_al1rl , response_lromfert_coarse_sf-1.96*response_lromfert_coarse_s$se) ,  
      lty = 3 , lwd = 1 , col = "black")
lines(smooth.spline(lromfert_fine$fertcent_dist_gcic_al1rl , response_lromfert_fine_sf) , lwd=2 , lty=1, col = "blue")
lines(smooth.spline(lromfert_fine$fertcent_dist_gcic_al1rl , response_lromfert_fine_sf+1.96*response_lromfert_fine_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "blue")
lines(smooth.spline(lromfert_fine$fertcent_dist_gcic_al1rl , response_lromfert_fine_sf-1.96*response_lromfert_fine_s$se) ,  
      lty = 3 , lwd = 1 , col = "blue")

dev.copy(postscript,'gradlogn_al1zrawcounts_lromfert_spline_nonorm.eps')
dev.off()