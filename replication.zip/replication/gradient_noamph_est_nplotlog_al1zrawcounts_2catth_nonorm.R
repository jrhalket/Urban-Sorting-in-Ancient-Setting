

library(readxl)

mino_noamph_thick <- read_excel("mino_noamph_thick_grad_nonorm_al1z.xlsx")
mino_noamph_nonthick <- read_excel("mino_noamph_nonthick_grad_nonorm_al1z.xlsx")

hell_thick <- read_excel("hell_local_noamph_thick_grad_nonorm_al1z.xlsx")
hell_nonthick <- read_excel("hell_local_noamph_nonthick_grad_nonorm_al1z.xlsx")

lrom_noamph_thick <- read_excel("lrom_noamph_thick_grad_nonorm_al1z.xlsx")
lrom_noamph_nonthick <- read_excel("lrom_noamph_nonthick_grad_nonorm_al1z.xlsx")



library(gam)


mino_noamph_thick_lin <- gam(log1p(mnatk_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1mnath, family = gaussian, data=mino_noamph_thick)
mino_noamph_nonthick_lin <- gam(log1p(mnantk_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1mnath, family = gaussian, data=mino_noamph_nonthick)


mino_noamph_thick_s <- gam(log1p(mnatk_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1mnath), family = gaussian, data=mino_noamph_thick)
mino_noamph_nonthick_s <- gam(log1p(mnantk_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1mnath), family = gaussian, data=mino_noamph_nonthick)



response_mino_noamph_thick_lin <- predict(mino_noamph_thick_lin,  se.fit=T)
response_mino_noamph_nonthick_lin <- predict(mino_noamph_nonthick_lin,  se.fit=T)


response_mino_noamph_thick_linf <- response_mino_noamph_thick_lin$fit
response_mino_noamph_nonthick_linf <- response_mino_noamph_nonthick_lin$fit

indf_mino_noamph_nonthick<-mino_noamph_nonthick$fertcent_dist_gcic_al1mnath
indf_mino_noamph_thick<-mino_noamph_thick$fertcent_dist_gcic_al1mnath

response_mino_noamph_thick_linf <- response_mino_noamph_thick_linf+(1-response_mino_noamph_thick_linf[[which.min(indf_mino_noamph_thick)]])
response_mino_noamph_nonthick_linf <- response_mino_noamph_nonthick_linf+(1-response_mino_noamph_nonthick_linf[[which.min(indf_mino_noamph_nonthick)]])

par(mfcol=c(1,1))

grad_mino_noamph_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(0.25,1.05), xlim=c(0,5000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(mino_noamph_thick$fertcent_dist_gcic_al1mnath , response_mino_noamph_thick_linf) , lwd=2 ,lty=1, col = "magenta")
lines(smooth.spline(mino_noamph_thick$fertcent_dist_gcic_al1mnath , response_mino_noamph_thick_linf+1.96*response_mino_noamph_thick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(mino_noamph_thick$fertcent_dist_gcic_al1mnath , response_mino_noamph_thick_linf-1.96*response_mino_noamph_thick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(mino_noamph_nonthick$fertcent_dist_gcic_al1mnath , response_mino_noamph_nonthick_linf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(mino_noamph_nonthick$fertcent_dist_gcic_al1mnath , response_mino_noamph_nonthick_linf+1.96*response_mino_noamph_nonthick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(mino_noamph_nonthick$fertcent_dist_gcic_al1mnath , response_mino_noamph_nonthick_linf-1.96*response_mino_noamph_nonthick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_na_al1zrawcounts_mino_noamph_linear_nonorm.eps')
dev.off()


response_mino_noamph_thick_s <- predict(mino_noamph_thick_s,  se.fit=T)
response_mino_noamph_nonthick_s <- predict(mino_noamph_nonthick_s,  se.fit=T)


response_mino_noamph_thick_sf <- response_mino_noamph_thick_s$fit
response_mino_noamph_nonthick_sf <- response_mino_noamph_nonthick_s$fit


response_mino_noamph_thick_sf <- response_mino_noamph_thick_sf+(1-response_mino_noamph_thick_sf[[which.min(indf_mino_noamph_thick)]])
response_mino_noamph_nonthick_sf <- response_mino_noamph_nonthick_sf+(1-response_mino_noamph_nonthick_sf[[which.min(indf_mino_noamph_nonthick)]])

par(mfcol=c(1,1))

grad_mino_noamph_s <- plot(0, type="n", bty="n", xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0,1.05), xlim=c(0,5000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(mino_noamph_thick$fertcent_dist_gcic_al1mnath , response_mino_noamph_thick_sf) , lwd=2 ,lty=1, col = "magenta")
lines(smooth.spline(mino_noamph_thick$fertcent_dist_gcic_al1mnath , response_mino_noamph_thick_sf+1.96*response_mino_noamph_thick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(mino_noamph_thick$fertcent_dist_gcic_al1mnath , response_mino_noamph_thick_sf-1.96*response_mino_noamph_thick_s$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(mino_noamph_nonthick$fertcent_dist_gcic_al1mnath , response_mino_noamph_nonthick_sf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(mino_noamph_nonthick$fertcent_dist_gcic_al1mnath , response_mino_noamph_nonthick_sf+1.96*response_mino_noamph_nonthick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(mino_noamph_nonthick$fertcent_dist_gcic_al1mnath , response_mino_noamph_nonthick_sf-1.96*response_mino_noamph_nonthick_s$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_na_al1zrawcounts_mino_noamph_spline_nonorm.eps')
dev.off()

hell_thick_lin <- gam(log1p(hlnatk_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hlnath, family = gaussian, data=hell_thick)
hell_nonthick_lin <- gam(log1p(hlnantk_gcic_al1_nonorm_1)~kastro_dist_gcic_al1hlnath, family = gaussian, data=hell_nonthick)


hell_thick_s <- gam(log1p(hlnatk_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hlnath), family = gaussian, data=hell_thick)
hell_nonthick_s <- gam(log1p(hlnantk_gcic_al1_nonorm_1)~s(kastro_dist_gcic_al1hlnath), family = gaussian, data=hell_nonthick)


response_hell_thick_lin <- predict(hell_thick_lin,  se.fit=T)
response_hell_nonthick_lin <- predict(hell_nonthick_lin,  se.fit=T)


response_hell_thick_linf <- response_hell_thick_lin$fit
response_hell_nonthick_linf <- response_hell_nonthick_lin$fit

indf_hell_nonthick<-hell_nonthick$kastro_dist_gcic_al1hlnath
indf_hell_thick<-hell_thick$kastro_dist_gcic_al1hlnath


response_hell_thick_linf <- response_hell_thick_linf+(1-response_hell_thick_linf[[which.min(indf_hell_thick)]])
response_hell_nonthick_linf <- response_hell_nonthick_linf+(1-response_hell_nonthick_linf[[which.min(indf_hell_nonthick)]])

par(mfcol=c(1,1))

grad_hell_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(0.85,1.10), xlim=c(0,600))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlnath , response_hell_thick_linf) , lwd=2 ,lty=1, col = "magenta")
lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlnath , response_hell_thick_linf+1.96*response_hell_thick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlnath , response_hell_thick_linf-1.96*response_hell_thick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlnath , response_hell_nonthick_linf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlnath , response_hell_nonthick_linf+1.96*response_hell_nonthick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlnath , response_hell_nonthick_linf-1.96*response_hell_nonthick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_na_al1zrawcounts_hell_linear_nonorm.eps')
dev.off()


response_hell_thick_s <- predict(hell_thick_s,  se.fit=T)
response_hell_nonthick_s <- predict(hell_nonthick_s,  se.fit=T)


response_hell_thick_sf <- response_hell_thick_s$fit
response_hell_nonthick_sf <- response_hell_nonthick_s$fit


response_hell_thick_sf <- response_hell_thick_sf+(1-response_hell_thick_sf[[which.min(indf_hell_thick)]])
response_hell_nonthick_sf <- response_hell_nonthick_sf+(1-response_hell_nonthick_sf[[which.min(indf_hell_nonthick)]])

par(mfcol=c(1,1))

grad_hell_s <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0.3,1.25), xlim=c(0,600))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlnath , response_hell_thick_sf) , lwd=2 ,lty=1, col = "magenta")
lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlnath , response_hell_thick_sf+1.96*response_hell_thick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_thick$kastro_dist_gcic_al1hlnath , response_hell_thick_sf-1.96*response_hell_thick_s$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlnath , response_hell_nonthick_sf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlnath , response_hell_nonthick_sf+1.96*response_hell_nonthick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(hell_nonthick$kastro_dist_gcic_al1hlnath , response_hell_nonthick_sf-1.96*response_hell_nonthick_s$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_na_al1zrawcounts_hell_spline_nonorm.eps')
dev.off()

lrom_noamph_thick_lin <- gam(log1p(rlnatk_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rlnath, family = gaussian, data=lrom_noamph_thick)
lrom_noamph_nonthick_lin <- gam(log1p(rlnantk_gcic_al1_nonorm_1)~potamos_dist_gcic_al1rlnath, family = gaussian, data=lrom_noamph_nonthick)


lrom_noamph_thick_s <- gam(log1p(rlnatk_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rlnath), family = gaussian, data=lrom_noamph_thick)
lrom_noamph_nonthick_s <- gam(log1p(rlnantk_gcic_al1_nonorm_1)~s(potamos_dist_gcic_al1rlnath), family = gaussian, data=lrom_noamph_nonthick)



response_lrom_noamph_thick_lin <- predict(lrom_noamph_thick_lin,  se.fit=T)
response_lrom_noamph_nonthick_lin <- predict(lrom_noamph_nonthick_lin,  se.fit=T)


response_lrom_noamph_thick_linf <- response_lrom_noamph_thick_lin$fit
response_lrom_noamph_nonthick_linf <- response_lrom_noamph_nonthick_lin$fit

indf_lrom_noamph_nonthick<-lrom_noamph_nonthick$potamos_dist_gcic_al1rlnath
indf_lrom_noamph_thick<-lrom_noamph_thick$potamos_dist_gcic_al1rlnath


response_lrom_noamph_thick_linf <- response_lrom_noamph_thick_linf+(1-response_lrom_noamph_thick_linf[[which.min(indf_lrom_noamph_thick)]])
response_lrom_noamph_nonthick_linf <- response_lrom_noamph_nonthick_linf+(1-response_lrom_noamph_nonthick_linf[[which.min(indf_lrom_noamph_nonthick)]])

par(mfcol=c(1,1))

grad_lrom_noamph_lin <- plot(0, type="n", bty="n",  xlab="Distance (meters)", 
                      ylab="Log raw counts", lwd=2,ylim=c(0.92,1.04), xlim=c(0,1500))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(lrom_noamph_thick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_thick_linf) , lwd=2 ,lty=1, col = "magenta")
lines(smooth.spline(lrom_noamph_thick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_thick_linf+1.96*response_lrom_noamph_thick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_noamph_thick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_thick_linf-1.96*response_lrom_noamph_thick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_noamph_nonthick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_nonthick_linf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(lrom_noamph_nonthick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_nonthick_linf+1.96*response_lrom_noamph_nonthick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(lrom_noamph_nonthick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_nonthick_linf-1.96*response_lrom_noamph_nonthick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_na_al1zrawcounts_lrompot_linear_nonorm.eps')
dev.off()


response_lrom_noamph_thick_s <- predict(lrom_noamph_thick_s,  se.fit=T)
response_lrom_noamph_nonthick_s <- predict(lrom_noamph_nonthick_s,  se.fit=T)


response_lrom_noamph_thick_sf <- response_lrom_noamph_thick_s$fit
response_lrom_noamph_nonthick_sf <- response_lrom_noamph_nonthick_s$fit


response_lrom_noamph_thick_sf <- response_lrom_noamph_thick_sf+(1-response_lrom_noamph_thick_sf[[which.min(indf_lrom_noamph_thick)]])
response_lrom_noamph_nonthick_sf <- response_lrom_noamph_nonthick_sf+(1-response_lrom_noamph_nonthick_sf[[which.min(indf_lrom_noamph_nonthick)]])

par(mfcol=c(1,1))

grad_lrom_noamph_s <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                    ylab="Log raw counts", lwd=2,ylim=c(0.6,1.1), xlim=c(0,1500))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(lrom_noamph_thick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_thick_sf) , lwd=2 ,lty=1, col = "magenta")
lines(smooth.spline(lrom_noamph_thick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_thick_sf+1.96*response_lrom_noamph_thick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_noamph_thick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_thick_sf-1.96*response_lrom_noamph_thick_s$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_noamph_nonthick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_nonthick_sf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(lrom_noamph_nonthick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_nonthick_sf+1.96*response_lrom_noamph_nonthick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(lrom_noamph_nonthick$potamos_dist_gcic_al1rlnath , response_lrom_noamph_nonthick_sf-1.96*response_lrom_noamph_nonthick_s$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_na_al1zrawcounts_lrompot_spline_nonorm.eps')
dev.off()

library(readxl)


lrom_noamphfert_thick <- read_excel("lrom_noamphfert_thick_grad_nonorm_al1z.xlsx")
lrom_noamphfert_nonthick <- read_excel("lrom_noamphfert_nonthick_grad_nonorm_al1z.xlsx")

lrom_noamphfert_thick_lin <- gam(log1p(rlnatk_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rlnath, family = gaussian, data=lrom_noamphfert_thick)
lrom_noamphfert_nonthick_lin <- gam(log1p(rlnantk_gcic_al1_nonorm_1)~fertcent_dist_gcic_al1rlnath, family = gaussian, data=lrom_noamphfert_nonthick)


lrom_noamphfert_thick_s <- gam(log1p(rlnatk_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rlnath), family = gaussian, data=lrom_noamphfert_thick)
lrom_noamphfert_nonthick_s <- gam(log1p(rlnantk_gcic_al1_nonorm_1)~s(fertcent_dist_gcic_al1rlnath), family = gaussian, data=lrom_noamphfert_nonthick)



response_lrom_noamphfert_thick_lin <- predict(lrom_noamphfert_thick_lin,  se.fit=T)
response_lrom_noamphfert_nonthick_lin <- predict(lrom_noamphfert_nonthick_lin,  se.fit=T)


response_lrom_noamphfert_thick_linf <- response_lrom_noamphfert_thick_lin$fit
response_lrom_noamphfert_nonthick_linf <- response_lrom_noamphfert_nonthick_lin$fit

indf_lrom_noamphfert_nonthick<-lrom_noamphfert_nonthick$fertcent_dist_gcic_al1rlnath
indf_lrom_noamphfert_thick<-lrom_noamphfert_thick$fertcent_dist_gcic_al1rlnath


response_lrom_noamphfert_thick_linf <- response_lrom_noamphfert_thick_linf+(1-response_lrom_noamphfert_thick_linf[[which.min(indf_lrom_noamphfert_thick)]])
response_lrom_noamphfert_nonthick_linf <- response_lrom_noamphfert_nonthick_linf+(1-response_lrom_noamphfert_nonthick_linf[[which.min(indf_lrom_noamphfert_nonthick)]])

par(mfcol=c(1,1))

grad_lrom_noamphfert_lin <- plot(0, type="n", bty="n", xlab="Distance (meters)", 
                          ylab="Log raw counts", lwd=2,ylim=c(0.97,1.04), xlim=c(0,3000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))


lines(smooth.spline(lrom_noamphfert_thick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_thick_linf) , lwd=2 ,lty=1, col = "magenta")
lines(smooth.spline(lrom_noamphfert_thick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_thick_linf+1.96*response_lrom_noamphfert_thick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_noamphfert_thick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_thick_linf-1.96*response_lrom_noamphfert_thick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_noamphfert_nonthick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_nonthick_linf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(lrom_noamphfert_nonthick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_nonthick_linf+1.96*response_lrom_noamphfert_nonthick_lin$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(lrom_noamphfert_nonthick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_nonthick_linf-1.96*response_lrom_noamphfert_nonthick_lin$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_na_al1zrawcounts_lrom_noamphfert_linear_nonorm.eps')
dev.off()


response_lrom_noamphfert_thick_s <- predict(lrom_noamphfert_thick_s,  se.fit=T)
response_lrom_noamphfert_nonthick_s <- predict(lrom_noamphfert_nonthick_s,  se.fit=T)


response_lrom_noamphfert_thick_sf <- response_lrom_noamphfert_thick_s$fit
response_lrom_noamphfert_nonthick_sf <- response_lrom_noamphfert_nonthick_s$fit


response_lrom_noamphfert_thick_sf <- response_lrom_noamphfert_thick_sf+(1-response_lrom_noamphfert_thick_sf[[which.min(indf_lrom_noamphfert_thick)]])
response_lrom_noamphfert_nonthick_sf <- response_lrom_noamphfert_nonthick_sf+(1-response_lrom_noamphfert_nonthick_sf[[which.min(indf_lrom_noamphfert_nonthick)]])

par(mfcol=c(1,1))

grad_lrom_noamphfert_s <- plot(0, type="n", bty="n",  xlab="Distance (meters)",  
                        ylab="Log raw counts", lwd=2,ylim=c(0.95,1.15), xlim=c(0,3000))
legend("topright", bty="n", lwd=2, lty=c(1,5), col=c("magenta","orange"), legend=c("Thick", "Non-Thick"))

lines(smooth.spline(lrom_noamphfert_thick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_thick_sf) , lwd=2 ,lty=1, col = "magenta")
lines(smooth.spline(lrom_noamphfert_thick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_thick_sf+1.96*response_lrom_noamphfert_thick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_noamphfert_thick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_thick_sf-1.96*response_lrom_noamphfert_thick_s$se) ,  
      lty = 3 , lwd = 1 , col = "magenta")
lines(smooth.spline(lrom_noamphfert_nonthick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_nonthick_sf) , lwd=2 , lty=5, col = "orange")
lines(smooth.spline(lrom_noamphfert_nonthick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_nonthick_sf+1.96*response_lrom_noamphfert_nonthick_s$se) , 
      lty  
      = 3 , lwd = 1 , col = "orange")
lines(smooth.spline(lrom_noamphfert_nonthick$fertcent_dist_gcic_al1rlnath , response_lrom_noamphfert_nonthick_sf-1.96*response_lrom_noamphfert_nonthick_s$se) ,  
      lty = 3 , lwd = 1 , col = "orange")

dev.copy(postscript,'gradlogn2catth_na_al1zrawcounts_lrom_noamphfert_spline_nonorm.eps')
dev.off()